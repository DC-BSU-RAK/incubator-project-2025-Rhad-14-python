label Chapter_11_Protect:
    narrator "The chamber shook harder with each shard shooting out the ground. Magic blasts lit up the air while rocks cracked and fell from the ceiling."
    
    show damon scream at leylinetint with dissolve
    damon "\"Dante!\""
    
    hide damon with dissolve
    narrator "Debris from the ceiling was about to harm Dante but Damon shoved him out of the way, taking the hit instead. He hisses in pain as he curls up, clutching his side."
    
    show side dante scared at left, leylinetint onlayer dante with dissolve 
    dante "\"Damon!\""

    hide side dante onlayer dante with dissolve
    narrator "The mages kept attacking, blasting through the crystals — but it shot back more. The cave was now covered with crystals, with the mining team stuck at the entrance, unable to do anything."

    narrator "The mages were working overtime, blasting the obstacles away."
    
    show warden shout at leylinetint with dissolve
    warden "\"Finish it! Get the crystal before this place collapses!\""
    
    hide warden with dissolve
    narrator "One mage got too close to the vein and touched a loose crystal spike. It shattered in their hand, and a shockwave knocked them back into the wall."

    narrator "The ground split wider under Dante's feet, the air now feeling heavier and electrifying."

    narrator "Dante looked between his brother on the ground and the shaking crystal."
    
    narrator "Damon coughed, trying to push himself up."
    
    show damon scream at leylinetint with dissolve
    damon "\"Dante... You have to go! Get away from this place!\""
    
    hide damon with dissolve
    narrator "But Dante knew he had seconds to choose."

    menu:
        "*Run to the crystal and resonate with it*":
            $ saved_crystal = True
            jump touch_crystal
        "*Help Damon up*":
            $ saved_crystal = False
            jump help_damon

    label touch_crystal:
        narrator "Dante knew the risks. He knew what would happen if he were to do this, but he ran straight to leyline vein without any hesitation."

        narrator "Any prize worth that much wouldn’t matter if the world would be plunged into chaos. Elliot would understand the urgency."

        narrator "Dante ran straight for the vein, ignoring Damon's shouts."

        narrator "The warden was frustrated with the mages falling back and took one of their staffs, as he wanted to finish the job."

        show warden talk at leylinetint with dissolve
        warden "\"Fine, I’ll do it myself\""

        hide warden with dissolve
        narrator "Before he could even try, Dante tackles him, making him drop the staff in the process. He quickly gets back on his feet and puts himself in front of the crystal once again. This time, he was prepared to blast the warden with a fireball."

        narrator "The warden froze as he saw the small boy with a fireball ready on one hand. Despite that, he laughed it off."

        show warden sneer at leylinetint with dissolve
        warden "\"You may stop me now, but there are other mages here that can reduce you to nothing. Face it, you’re outnumbered.\""

        hide warden with dissolve
        narrator "Dante didn’t say anything, but he placed his hands on the crystal, causing the cavern to tremble as he strengthened the crystal even further with his magic."

        narrator "Suddenly, a roar could be heard in the cave. The warden turns his head to the direction of the noise — the rumble of something charging in their direction."

        show side dante determinedtalk at left,leylinetint onlayer dante with dissolve
        dante "\"I warned you...\""

        hide side dante onlayer dante with dissolve
        narrator "Everything happened so fast. Monsters suddenly rushed in and started to pick off the mages one by one, taking down those who dared to lay a hand on the crystal."

        narrator "One mage attempted to blast Dante while he had his back turned, but a beast pounced on him and tore him apart before the warden’s eyes."

        narrator "The warden watches in absolute horror as the beasts make a meal out of the mages he hired. He noticed the miners weren't getting approached by the monsters and started to run straight to Dante, whose hands were still on the heart of the leyline."

        show warden scared at leylinetint with dissolve
        warden "\"Please! Spare me! You can take the other mages, but don’t let them maul me!\""

        hide warden with dissolve
        narrator "The warden begged and cried pitifully before the boy. Dante never thought he would see the warden in this state, but he simply turned his head away and let the beasts make a meal out of him."

        narrator "Damon watches his brother massacre the mages with the beasts before his eyes, as he tries to pull his brother away and escape the cave."

        show damon scream at leylinetint with dissolve
        damon "We need to go!"

        show side dante determinedtalk at left, leylinetint onlayer dante with dissolve
        show damon struggle
        dante "No, you go! Take the pendant and seal off the entrance."

        show side dante determined onlayer dante
        show damon scream
        damon "What!? No, I-"

        show damon struggle
        show side dante determinedtalk onlayer dante
        dante "Please, take the pendant and the other miners out of here! Use it as your compass to guide everyone to safety, I’ll deal with those people myself."

        show side dante determined onlayer dante
        narrator "Damon hesitated for a moment but ultimately agreed with a heavy heart. He takes the pendant, but not without one last hug, and goes to the other miners."
        
        stop rumblefx fadeout 6.0
        hide damon 
        hide side dante onlayer dante
        with dissolve
        scene bg black with fade
        stop music fadeout 4.5
        narrator "Damon guides the others out of the cave and seals off the entrance of the cavern. Just after, a massive tremor shook the cave once more, with rubble falling down, blocking the entrance for good." 

        narrator "Damon looks away in horror but persists on, wanting to fulfill his brother’s request."

        scene barracks-day with longfade
        play music "<silence 0.5>"
        queue music "audio/soft_full.ogg" volume 0.2 
        narrator "..."

        narrator "Damon spoke with Elliot, about everything that transpired in the cave. He understood their circumstances and thanked him for finding the ore."

        narrator "He still offered the money and his freedom despite not retrieving the leyline. After all, they did go through all that trouble to find it."
        
        scene bg black with fade
        narrator "In the end, he accepted the compensation along with the freedom of the team that accompanied the brothers at the start."

        narrator "Damon and the team bid farewell to the other miners as they left the barracks on a wagon heading towards a small town."

        narrator "Damon sits silently as the carriage moves, fidgeting with the pendant around his neck. As much as he missed his brother, he understood that this was what needed to be done."

        narrator "If this was guaranteed to prolong a time of peace, then so be it. The new shards of the leyline sprouting out around the cave gave him assurance that what his brother did was for their betterment."

        narrator "As for him, he might as well use the money to live out the life that they both would have had."
        $ unlock_achievement("You achieved the neutral ending. (2/3)")
        jump credits

    label help_damon:
        narrator "Dante dropped to his knees beside Damon and grabbed his arm."

        show side dante determinedtalk at left, leylinetint onlayer dante with dissolve
        dante "\"Come on! We gotta move!\""

        show side dante determined onlayer dante
        narrator "Dante goes and grabs Damon as they proceed to leave the crumbling place with the other miners, leaving the mages and the warden to fend for themselves."

        narrator "The sound of a roar was heard from an entrance made in the wall, with the adults turning their heads to the direction of the sound. There was something charging in their direction."

        show side dante determinedtalk onlayer dante
        dante "\"We need to leave now.\""

        hide side dante onlayer dante with dissolve
        narrator "He urges the other miners out the entrance as quickly as they can, not before lighting a stick of dynamite and throwing it by a crack at the wall."

        stop rumblefx fadeout 6.0
        scene bg black with fade
        stop music fadeout 4.5
        narrator "He leaves and seals the entrance with the pendant, as the dynamite explodes and opens a hidden tunnel that was blocked by rubble."

        narrator "Now the only ones left were the mages and the warden, and the leyline."

        narrator "They triumphantly celebrate at the new found exit with the warden calling Dante an idiot for giving them an exit, but the cheers were cut short when they realized..."

        narrator "...The “exit” was leading the monsters to them."

        narrator "Everything happened so fast — monsters suddenly rushed in and started to pick off the mages one by one, tearing everyone apart with no mercy."

        narrator "Everyone was torn up, leaving the warden as the last one standing."

        narrator "The warden has himself backed against the wall, waving around his short sword as his only means of defense."

        show warden scared at nighttint with dissolve        
        warden "\"Stay back!\""

        hide warden with dissolve
        narrator "One of the beasts roar and then pounces on the man, with the others following him. They maul him to shreds as he screams in agony at the pain."

        #The Baracks
        scene barracks-day with longfade
        play music "<silence 0.5>"
        queue music "audio/soft_full.ogg" volume 0.2 
        narrator "..."
        narrator "Everyone arrives back to the barracks in one piece, but they were still shaken at what they witnessed. Nonetheless, they all couldn’t afford to stay stagnant."

        narrator "Dante and Damon spoke with Elliot about everything that transpired in the cave. He understood their circumstances and thanked the boys for finding the ore."

        narrator "He still offered them money and their freedom despite not having retrieved the leyline. After all, they did go through all that trouble to find it."

        scene bg black with fade
        narrator "In the end, they both accepted the compensation along with the freedom of the team that accompanied the brothers at the start."

        narrator "The brothers, along with the team, bid farewell to the other miners as they left the barracks on a wagon heading towards a small town."

        show damon talk at daytint with dissolve
        damon "\"You okay?\""

        show side dante happy at left, daytint onlayer dante with dissolve
        show damon happy
        narrator "Dante nods assuringly, but nonetheless, he couldn’t believe everything that happened. He tries not to let all of that get to his head, as he instead listens in on the conversation being shared within the group."
        
        narrator "At this point, they might as well use the money to live out the life that they both would have."
        hide damon
        hide side dante onlayer dante
        with dissolve
        $ unlock_achievement("You achieved the good ending. (1/3)")
        jump credits