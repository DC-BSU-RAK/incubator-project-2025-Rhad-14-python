label Chapter_9:
    hide warden with dissolve
    narrator "Damon turns his attention to the group of people entering through the blown up entrance. Horror filled his face as he struggled to stand on his two feet."
    
    show damon scream at leylinetint with dissolve
    damon "How?! How did you find this place?!"
    
    hide damon with dissolve
    narrator "Dante's stomach dropped as he saw the torches lighting up familiar faces from their expedition team. Anne. Bernard. Some of the miners. All looking exhausted but determined."
    
    anne "\"Dante! Damon! You’re alive!\""

    bernard "\"You did well in giving signs that lead to this place, otherwise we would be lost in this cave.\""

    narrator "Then it hit him."
    
    narrator "The marks."
    
    narrator "The stone arrows."
    
    narrator "The scratched symbols he'd left for Damon."
    
    narrator "They'd followed his trail."

    narrator "He made it for his brother to find him, but they were the ones who found them instead. He led them here. They’re here because of him."
    
    show side dante scared at left, leylinetint onlayer dante with dissolve
    dante "\"Oh no...\""

    show warden shout at leylinetint with dissolve
    warden "\"Out of the way!\""
    
    narrator "The warden pushed through the group, smirking as he stepped into the crystal light. His uniform was torn and dusty, but his eyes gleamed with greed."
    
    show warden smug 
    warden "\"Would you look at that? He actually did it.\""
    
    narrator "He clapped slowly, the sound echoing off the crystal walls."

    narrator "He laughed as he approached the crystal vein."
    
    show warden talk
    warden "\"I thought you were just another dud, boy.\""
    
    warden "\"All that crap about magic. I thought nothing about it made you any special, but I was wrong. You actually found it, I’ll give you that.\""

    narrator "He spread his arms toward the glowing leyline vein."
    
    warden "\"It’s mine, all mine. Elliot’s prize and my promotion, oh things are truly coming all my way.\""
    
    show side dante determinedtalk onlayer dante
    dante "\"Hey! That offer belongs to my brother, you dirty cheat!\""

    show side dante determined onlayer dante
    show warden shout
    warden "\"Watch it! You’re lucky that I’m not disposing of you right now. So shut your mouth!\""

    narrator "Dante stood frozen as the warden turned to his mages."
    
    show warden talk
    warden "\"Step aside, runt. Let the real magicians do their job.\""
    
    narrator "The mages moved forward, staffs glowing as they began chanting. The miners fanned out behind them, tools ready to harvest whatever they could carry."
    
    narrator "Damon growled and tried to lunge forward, but his injured leg buckled immediately. He hit the ground hard, grimacing in pain."
    
    show warden neutral with moveinright:
        xalign 1.0
    show damon screamside at leylinetint with dissolve:
        xalign -0.1
        xzoom -1.0
    damon "\"No!!! You can't take it! Stop!\""
    
    narrator "The warden barely glanced at him."
    
    show damon strugglecloseside
    show warden talk
    warden "\"Stay down, slave. If you have any common sense left, you’ll stay out and shut your pathetic mouth.\""
    
    hide damon
    hide warden
    hide side dante scared onlayer dante
    with dissolve
    narrator "Damon clawed at the ground, trying to drag himself up, but it was no use. He was too weak."
    
    narrator "Dante watched it all happen, heart pounding."
    
    narrator "The mages were almost at the crystal now. Damon was struggling just to breathe. The warden was grinning like he'd already won."
    
    narrator "Everything from the vision flashed through his head."
    
    narrator "Lumina's warning."
    
    narrator "The balance."
    
    narrator "The beasts."
    
    stop music fadeout 6.0
    narrator "The last vein."

    menu: 
        "*Protect the crystal with damon*":
            jump Chapter_10_Protect

        "*Step aside and let the warden take it*":
            jump Chapter_10_Step_aside