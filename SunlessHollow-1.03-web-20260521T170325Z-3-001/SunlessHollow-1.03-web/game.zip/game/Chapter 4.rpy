label Chapter_4:
    scene messhall with longfade
    narrator "The day has come to find the leyline. Dante and Damon gathered their team, saying farewell to their friends before setting off."

    show rowan sad at outsidetint with dissolve
    rowan "\"Goodbye, Dante. Please come back safe with your limbs still intact.\""

    menu:
        "*You chuckle at the statement*":
            show side dante talk at left, outsidetint onlayer dante with dissolve
            dante "\"I’ll be back in one piece, I promise.\""
        "*You playfully nudge him lightly on the side with your elbow*":
            show side dante talk at left, outsidetint onlayer dante with dissolve
            dante "\"I’ll be back in one piece, I promise.\""
        "*You bring him in for a tight hug*":
            show side dante talk at left, outsidetint onlayer dante with dissolve
            dante "\"I’ll be back in one piece, I promise.\""
    
    show side dante happy onlayer dante
    narrator "His brother calls him over as they are about to go. With one last goodbye, Dante, Damon, and the rest of the team bid farewell to their loved ones, as this expedition might serve as their last."
    hide rowan 
    hide side dante happy onlayer dante
    with dissolve

    play music "audio/phrase5.ogg" fadein 3.0
    scene mine-1 with longfade
    narrator "The team is now far away from any of the safe zones. They are on their own now, but they have come prepared for any danger that could come at them."

    narrator "The trip was quite an awkward one, to say the least. What should be filled with an abundance of conversation, is instead replaced with nothing but dead silence amongst the group."

    narrator "They weren't sure on how to break the ice, considering they have a noticeably much younger member along with them."

    narrator "As they continued on for the next hour, one of the members decided to break the awkward silence as they continued walking."

    anne "\"So, I want to address this now... Is it true?\""

    narrator "She directs her question at Dante."

    show side dante question at left, nighttint onlayer dante with dissolve
    dante "\"What’s true?\""

    show side dante neutral onlayer dante
    anne "\"About you having magic?\""

    narrator "The team stops at their tracks as soon as magic was mentioned. They turned their heads briefly to hear what the boy would say of the apparent rumour of his magical capabilities."

    narrator "Dante turns to his brother briefly, as if asking what to do. Damon nods briefly, encouraging his brother to speak."

    show side dante question onlayer dante
    dante "\"Um... Yes?\""

    show side dante neutral onlayer dante
    hide side dante neutral onlayer dante with dissolve
    anne "\"That’s amazing! I've never met anyone who had magic.\""

    narrator "The girl starts praising and asking questions about the boy’s magic with curiosity and excitement. As the girl continues on, the others in the group follow suit with their curiosity and praise for the young scrawny boy."

    narrator "At this point, the group is barraging Dante with questions, leaving the boy overwhelmed by the group’s pestering."

    narrator "Seeing his brother overwhelmed, Damon clears his throat, doing a fake cough to grab their attention. The group turns to the taller boy."

    show damon talk at nighttint with dissolve
    damon "\"Let’s get moving. You can keep asking questions on the way. Don't forget, we're here to find some rare ore.\""

    show damon happy
    hide damon with dissolve
    narrator "The group agrees as they continue further in the cave, with Dante moving forward to the front of the party by his brother."
    
    narrator "Time had passed since they left the barracks, and the team seem livelier than before as Bernard, the group’s navigator, led them through the cave's dark corners."

    narrator "The group continues to ask the little boy about his magic. The questions even go further to his rebellion against the warden."

    anne "\"Can you read minds with your magic?\""

    robert "\"Can you make things explode with your magic?\""

    gabriel "\"Is it true that you bit the warden? You need to tell me more about it!\""

    amity "\"How do you have the courage to face the warden? I just cower when he comes.\""

    narrator "Overwhelmed once again by their bombardment of questions, Dante retreats to his older brother's side like a little puppy. Damon chuckled at the sight as he ruffled his brother's hair."

    show side dante question at left, nighttint onlayer dante with dissolve 
    dante "{cps=59}\"How do you handle this?\""

    narrator "Dante ponders how someone could handle stuff like this."

    show side dante happy onlayer dante
    show damon talk at nighttint with dissolve
    damon "\"You’ll get used to it, don't worry.\""

    show damon talkneutral
    damon "\"...Let’s settle here for now. We've walked for quite a while now, so it's only right that we rest.\""

    damon "\"Though stay silent. We're no longer in the safe zones, so we're more vulnerable to the cave monsters down here.\""

    hide side dante happy onlayer dante
    hide damon
    with dissolve
    narrator "The group sits down by the rubble, with some putting their backpacks away on the side." 
    
    narrator "As most of the group chatter away, sharing stories and checking their supplies and gear, Dante walks over to Damon and another group member as they study a map of the cave and its tunnels."

    show damon talkneutral at nighttint with dissolve
    damon "\"...Where would you say we are right now?\""

    show damon neutral
    bernard "\"We have already passed this landmark at the end of the map, so we're right now in uncharted territory.\""

    bernard "\"I'll keep a record around these tunnels as we go, but we’ll be on our own at this moment.\""

    narrator "Damon and Bernard notices Dante standing there, who was listening in their conversation."

    show damon talk
    damon "\"Perfect timing. We don't have to worry much about that, because we have Dante as our compass.\""

    show damon happy
    show side dante happy at left, nighttint onlayer dante with dissolve
    narrator "He shows Dante off like a proud mother to a son, leaving Bernard confused on what he could be referring to."

    show damon talk
    damon "\"I was told that since he has magic, he naturally feels the connection to the leyline. For that reason, he is our compass.\""

    show damon happy
    bernard "\"Well no wonder he came along. There really is more than meets the eye with this little guy.\""

    bernard "\"Well, with your magic and my navigation skills, we'll be a great team, won't we?\""

    show side dante talk onlayer dante
    dante "\"...Yeah, we would.\""

    show side dante happy onlayer dante
    narrator "Damon smiles at this small exchange, happy that there are some people that he is at least comfortable with. Dante walks over to his brother as he packs his backpack."

    show side dante talk onlayer dante
    dante "\"I like them, they're actually nice. I'll tell Elliot to grant them their freedom after this. I'll even share some of the reward with them.\""

    stop music fadeout 6.0
    show damon talk
    show side dante happy onlayer dante
    damon "\"That's nice.\""

    hide side dante happy onlayer dante
    hide damon 
    with dissolve
    play sound "<silence 1.0>"
    queue sound "audio/growl1.ogg" volume 0.5
    play music "audio/danger_full.ogg" fadein 3.0 volume 0.4
    narrator "Suddenly, the group hears something in the distance — a strange, unfamiliar sound. From how unnatural it is, it definitely belongs to some kind of cave beast." 
    
    narrator "The sound is indistinguishable — unnatural, even — not like the usual beasts of the cave. One of the members cautiously raises their lantern toward the source of the sound, hoping to catch a glimpse of the monstrosity before them."
    
    scene monsterscene with fade:
        anchor (0.3, 0.2)
        pos (0.3, 0.2)
        zoom 2.0
    narrator "Long limbs..."

    narrator "Sharp teeth..."

    narrator "Eyes reflecting the light like shards of glass..."
    scene monsterscene:
        anchor (0.3, 0.2)
        pos (0.3, 0.2)
        zoom 2.0
        linear 2 xpos 0.5
    narrator "A cave beast. And it wasn’t alone."

    scene monsterscene:
        anchor (0.3, 0.2)
        pos (0.3, 0.2)
        zoom 2.0
        easein 1 zoom 1.0
        anchor (0.5, 0.5)
        pos (0.5, 0.5)
    play sound "<silence 0.8>"
    queue sound "audio/growl2.ogg"
    narrator "Before they could act, the beasts lunged at them."

    scene monsterscene:
        anchor (1.0, 0.0)
        pos (1.0, 0.0)
        easeout 1.5 zoom 1.6
    damon "\"Everyone, fall back! Stay together!\""

    scene monsterscene:
        anchor (1.0, 0.0)
        pos (1.0, 0.0)
        zoom 1.6
        easein 1.5 zoom 1.0
        anchor (0.5, 0.5)
        pos (0.5, 0.5)
    narrator "The group scattered to avoid the coordinated attack, but in the chaos, most of the lamps shattered against the rocky ground, causing the creatures to become even more erratic."
    
    narrator "The cavern descended into chaos as the team scattered like mice into different corners despite the darkness. Some managed to grab their backpacks in the rush, while others lost their belongings to the monsters tearing them apart."

    narrator "Dante ran behind a boulder, hiding from the monsters and hoping the beasts hadn't seen him. He felt strange — he had never felt anything like this before, and he hated it. He didn't want people to die because of him, especially his brother."
    
    narrator "But he didn't know what to do. He had magic, yet he couldn't move. He couldn't do anything except hide like a coward."
    
    show side dante scared at left, nighttint onlayer dante with dissolve 
    narrator "What was this feeling? His heart pounded rapidly in his chest, as if it were ready to burst out at any moment. Cold sweat dripped down his forehead, and his breathing grew faster with every passing second."
  
    narrator "The sounds of chaos slowly faded from his ears, replaced only by a piercing ringing. He hadn't felt this way in a long time — not this badly — not since he was first terrorized by the warden..."

    narrator "{cps=10}He felt {b}FEAR.{/b}"
    
    hide side dante scared onlayer dante with dissolve
    narrator "As Dante shifted slightly, he knocked over a rock, the subtle noise loud enough to alert one of the beasts. It charged toward his hiding place."
    
    #play sound "<volume 0.7>audio/fizz2.ogg"
    scene monsterscene:
        anchor (1.0, 0.3)
        pos (1.0, 0.3)
        easeout 1.5 zoom 1.95
    play sound "<silence 1.0>"
    queue sound "audio/fizz.ogg"
    narrator "Meanwhile, Damon gathered the group one by one, trying to keep everyone together. But suddenly, one of the members lit a stick of dynamite and hurled it toward the monsters — and the remaining sticks of dynamite left behind."
    
    scene monsterscene:
        anchor (1.0, 0.3)
        pos (1.0, 0.3)
        zoom 1.95
        easein 1.5 zoom 1.0
        anchor (0.5, 0.5)
        pos (0.5, 0.5)
    play sound "<silence 1.9>"
    queue sound "audio/explosion2_rock.ogg" volume 0.8
    narrator "Seeing the explosive land near his brother, Damon rushed toward Dante to shield him from the blast. At the same time, the other monsters gathered at the sound of the burning fuse, and a thunderous boom echoed throughout the tunnel."
    scene monsterscene:
        zoom 1.05
    init python :
        renpy.music.register_channel("rumblefx", mixer="sfx", loop=True)
    play rumblefx "audio/rumble.ogg" volume 0.7 fadein 0.5
    show monsterscene at caveshake
        
    narrator "The explosion caused the cave to rumble violently as the cavern began to collapse. Chunks of stone rained from above, startling the creatures and forcing them to retreat. The cave was unstable, and the group needed to escape. {b}Now!{/b}"
    
    bernard "\"We need to leave!\""

    narrator "The party rushed to escape as quickly as possible, helping those who struggled to keep up. As they sprinted through the crumbling cavern, cracks spread across the floor beneath them, forcing the group to leap toward safer ground."
    
    narrator "Unfortunately, not everyone was fast enough. Dante and Damon fell through the collapsing floor, catching one final glimpse of the horrified party above them as someone screamed out for the brothers."

    anne "\"No!\""

    stop rumblefx fadeout 3.0
    scene black with fade
    narrator "As the brothers continued to fall, Damon reached for Dante, hoping to shield him from the impact. But the two were pulled into separate tunnels, tearing them away from each other."

    narrator "As Dante fell, he slammed against the cave walls again and again until his head struck the stone, leaving him disoriented."
    
    stop music fadeout 6.0
    narrator "The moment his body slid down the curved tunnel and crashed onto the rocky surface below, he finally lost consciousness from his injuries."
    jump Chapter_5