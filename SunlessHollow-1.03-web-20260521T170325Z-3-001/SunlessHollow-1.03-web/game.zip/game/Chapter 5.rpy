label Chapter_5:
    scene lushcave-1blur with dissolve
    narrator "His vision was blurry and disoriented as he tried to open his eyes. What happened? How did he end up on the ground? He could feel pain on all parts of his body."
    
    play sound "audio/crystal.ogg"
    scene lushcave-1 with dissolve
    narrator "So many questions are running through his head as he processed what was going on. Then it hit him.{w} The monsters.{w} The floor collapsing.{w} The team. His brother... Where was his brother?!"
    
    play music "audio/phrase1.ogg" fadein 1.8
    show side dante scared at left, outsidetint onlayer dante with dissolve
    dante "\"DAMON!\""

    #play music "audio/lush_highoct_loop.ogg" fadein 3.0 volume 0.5
    hide side dante scared onlayer dante with dissolve
    narrator "The boy’s body shot up in urgency, but winced back at the immediate shot of pain coursing around his body. He looks around, thinking his brother fell in the area too."

    dante "\"...Damon...?\""

    narrator "Dante drags his injured body as he starts looking for Damon."

    narrator "Dante took a good look at his surroundings. {w}Thick roots hung down from the cracks, strange mushrooms grew along the walls, some dull, some faintly glowing."

    narrator "The floor was soft in some places, covered with moss and damp soil instead of just rock."

    narrator "But what really stood out was the light."

    narrator "The whole place was lit up by clusters of crystals sprouting out of the ground and walls. They softly glowed in a variety of colors, bright enough for him to see without a lantern."

    show side dante question at left, outsidetint onlayer dante with dissolve
    dante "\"Where am I?\""

    narrator "He looks around, hoping Damon fell nearby through a different hole. The sound of water continued dripping somewhere, with a faint hum echoing in the air."
    
    dante "\"...Can’t find him…?\""

    hide side dante onlayer dante with dissolve
    narrator "His worried voice echoed a little, but there was no response."

    narrator "With each minute, Dante grows more frustrated. Damon is nowhere to be found. His supplies are missing... And there's no way to get back up from the hole."
    
    narrator "Dante clicks his tongue."

    show side dante talk at left, outsidetint onlayer dante with dissolve
    dante "\"Great... just great...\""

    hide side dante onlayer dante with dissolve
    menu:
        "\"Damon's fine. He has to be. He's strong.\"":
            jump there
        "\"No time to panic. I need to move.\"": 
            jump there
        "*Take a deep breath and force yourself to calm down*":
            jump there
    
    label there:
        narrator "Right now, all he can do is move forward and continue on finding the leyline. It’s not like he has any other option."

        narrator "He remembers that Elliot said that he can resonate and locate the crystal, since he received his magic from it."

        play sound "audio/cave_waterdrop.ogg" volume 0.5
        narrator "Dante tries and focuses on locating the crystal, but with every drip of water on a stray puddle echoing in the cavern, he grows more frustrated at the situation and just snaps."

        narrator "He throws a rock in the direction of the annoying noise, he hears the rock hit something that sounds like it shouldn’t belong there. He goes over to see what it was."

        narrator "That’s when he saw it."

        #play sound reveal
        scene skeletonpendant with fade:
            subpixel True
            xalign 0.5 yalign 0.5
            zoom 1.0
            linear 5 zoom 1.03
        narrator "Slumped against the wall, half-covered in moss and dirt, was a skeleton. Old clothes still clung to the bones, rotted and torn. Whoever they were, they had been here for a long time."

        narrator "Dante’s stomach twisted a little as he felt nauseous, but he moved closer anyway and saw something in the skeleton's neck."
        
        play sound "audio/pendant.ogg" volume 1.1
        narrator "A pendant."

        narrator "It was shaped like a small shard of crystal framed in a ring of metal, scratched and chipped, but still faintly shining. It definitely wasn’t standard miner gear."

        narrator "Dante hesitated for a moment."
       
    menu :
        "\"Uh... Sorry... I'll borrow this.\"":
            narrator "Dante takes the pendant."
        "\"You won't be needing this anymore.\"":
            narrator "Dante takes the pendant."
        "*Silently take the pendant*":
            narrator "Dante takes the pendant."

    narrator "Dante carefully lifted the pendant from the bones and slipped it over his own head."
    
    scene lushcave-1 with fade
    narrator "The metal felt cold at first."

    narrator "Then his chest reacted."

    narrator "That same spark of magic inside him flared up, like it just woke up too. The crystal on the pendant flickered, then began to glow softly."
    
    show side dante talk at left, outsidetint onlayer dante with dissolve
    dante "\"W-woah...\""
    
    show side dante shocked onlayer dante
    narrator "He held it up, watching the light pulse. At the same time, he felt something tug inside him, nudging him to turn in a certain direction, deeper into the cave."
    
    show side dante question onlayer dante
    dante "\"That's strange…?\""

    hide side dante onlayer dante with dissolve
    narrator "He slowly turned around again. The beam of light continued to shoot in the direction of the tunnel. He walked away from the tunnel and the beam prolonged with each step he took."
    
    narrator "It was acting like a compass."

    narrator "A weird, magic compass that was somehow reacting to him..?"

    show side dante talk at left, outsidetint onlayer dante with dissolve
    dante "\"Maybe I can use this...\""

    hide side dante onlayer dante with dissolve
    narrator "He let the pendant fall back against his chest, the pull still tugging him forward."

    narrator "When he started walking, another thought hit him."

    narrator "If he survived, then Damon might have too. And if Damon was somewhere else in this mess, he’d need a way to know Dante was alive and moving."

    narrator "Dante looked around, searching for anything he could use."

    narrator "There were broken pieces of wood from old crates, loose rocks, and scraps of cloth scattered around."

    narrator "He picked up a short plank and a small stone, then scratched a simple symbol into the wood: a circle with a line through it."

    show side dante talk at left, outsidetint onlayer dante with dissolve
    dante "\"There. That should stand out.\""

    show side dante neutral onlayer dante
    narrator "He propped the plank up near the spot where he woke up, tilted so it was easy to see."

    show side dante talk onlayer dante
    dante "If Damon finds this… He’ll know I passed through here. I’ll keep leaving these."

    hide side dante onlayer dante with dissolve
    menu:
        "\"You better find these. Damon.\"":
            narrator "He let out a small breath and finally started walking, letting the pendant guide him."
        "\"If I can follow this compass, you better follow my signs.\"":
            narrator "He let out a small breath and finally started walking, letting the pendant guide him."
        "*Stay quiet, but pat the plank once like a little ritual*":
            narrator "He let out a small breath and finally started walking, letting the pendant guide him."

    #play music "audio/wonder1.ogg" fadein 3.0 volume 0.5
    scene lushcave-2 with fade
    narrator "The deeper he went, the stranger it got."

    narrator "The tunnel didn’t feel like the dry, dead mine he grew up in. It felt… alive."

    narrator "Plants with wide leaves sprouted out from cracks in the stone. Thin vines curled along the walls, wrapping around the glowing crystals. Mushrooms of different sizes clustered together, some giving off a soft glow like lanterns."

    narrator "Up ahead, he heard the sound of running water."

    narrator "He followed it and turned a corner, finding a small stream cutting across the path. The water was crystal clear, flowing gently over smooth rocks."

    narrator "Dante crouched down and cupped some in his hands, taking a sip."

    show side dante talk at left, bluetint onlayer dante with dissolve
    dante "\"...Fresh.\""

    hide side dante onlayer dante with dissolve
    narrator "No dirt, no rust, no weird taste. Just clean water."

    narrator "It felt wrong that something this good existed under the same mine where they were barely given anything decent."
    
    show side dante question at left, bluetint onlayer dante with dissolve
    dante "\"How did nobody find this place...?\""

    hide side dante onlayer dante with dissolve
    narrator "He stood up again and decided to leave another sign."

    narrator "This time, he gathered a few stones and arranged them into an arrow on the ground, pointing in the direction the pendant was pulling."
    
    show side dante talk at left, bluetint onlayer dante with dissolve
    dante "\"Damon should be able to follow this…\""

    hide side dante onlayer dante with dissolve
    narrator "He kept moving, following the direction of the beam of light. As time passed on, more crystals can be found sprouting on the path."

    narrator "When he did, he could feel that buzz again, stronger here than anywhere else he’d ever been. It was like something flowed under the stone, slow but powerful."
    
    show side dante question at left, bluetint onlayer dante with dissolve
    dante "\"...This has to be close to a leyline, right?\""

    hide side dante onlayer dante with dissolve
    narrator "He wasn’t sure, but everything matched what Elliot said: stronger magic near the source, rare places where things still grew well, where water wasn’t poisoned."

    narrator "The pendant’s glow slowly got brighter the further he walked."

    narrator "Time was hard to track down here. No bells, no shift changes, no yelling wardens. Just the sound of water, his own footsteps, and his thoughts."

    narrator "After a while, his legs started to ache and his stomach let out a small growl."

    show side dante talk at left, bluetint onlayer dante with dissolve
    dante "\"...Guess I’ve been walking for a while.\""

    hide side dante onlayer dante with dissolve
    narrator "He stopped near a crystal cluster and sat down with his back against the wall."

    narrator "The pendant’s beam of light dimmed, like it understood he was resting."

    narrator "He closed his eyes for a short moment, just letting himself breathe."

    narrator "Even though he was alone, the place felt… less hopeless than the usual tunnels."

    narrator "The air felt cleaner. The light was softer. If he didn’t know better, he would have thought this was some hidden safe zone."

    narrator "But he did know better."

    show side dante talk at left, bluetint onlayer dante with dissolve
    dante "\"If this place is really this special… no wonder someone wanted to keep it hidden.\""

    hide side dante onlayer dante with dissolve
    narrator "He thought about the fallen miner with the pendant. How long had they been here? Were they also looking for the leyline? Did they find it first?"

    narrator "There was no way to know now."

    narrator "After a brief rest, Dante pushed himself back up."

    show side dante talk at left, bluetint onlayer dante with dissolve
    dante "\"Alright... I gotta keep moving.\""

    hide side dante onlayer dante with dissolve
    narrator "He adjusted the pendant again, making sure it sat securely against his chest, and started walking once more, deeper into the glowing, overgrown tunnels."

    narrator "This time, every few turns, he made sure to leave some kind of sign behind — scratched symbols on the wall, little stone arrows, anything that could point his brother in the right direction."

    narrator "If Damon was alive, he’d follow them. He had to."

    narrator "And even if nobody else did… At least the path Dante walked wouldn’t disappear completely."

    narrator "He kept going, letting the pendant pull him forward into the unknown."
    jump Chapter_6