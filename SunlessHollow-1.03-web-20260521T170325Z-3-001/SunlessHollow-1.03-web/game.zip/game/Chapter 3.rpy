label Chapter_3:
    show damon yessir
    show elliot lookside
    damon "\"A deal...?\""
    
    show damon neutral
    narrator "As the rich man presents his proposition, the brothers think over what kind of offer he could have for them. And even if they complete this deal, what would they even get out of this?"

    narrator "As selfish as it sounds, what reason would they have to help this person? After they finish this, what could they possibly offer that they would willingly help him with?"

    show elliot talk
    elliot "\"Yes, but before I explain further, there are some things that you need to know to fully understand the importance of this deal.\""

    elliot "\"First of all, do you understand why you have magic, young man?\""
    
    show elliot happy
    show side dante talk onlayer dante
    dante "\"Not really...\""
    
    show side dante neutral onlayer dante
    show elliot talk
    show damon lookside
    elliot "\"Well, that's all thanks to the leyline.\""
    
    show elliot happy
    show damon neutral
    narrator "The boys look at each other on what he could possibly be referring to. But one thing is certain — the leyline is what caused Dante to unlock magic."

    show damon lookside
    show side dante question onlayer dante
    dante "\"Leyline? What is that?\""
    
    show side dante neutral onlayer dante
    show elliot talk
    elliot "\"The leyline is a special deposit that grants magic to those who come in contact with it.\""

    elliot "\"First of all, do you understand why you have magic, young man?\""

    elliot "\"Since you have been here for quite some time, naturally your exposure to the leyline, though not close, gave you magic.\""
    
    show side dante neutral onlayer dante
    show elliot lookside
    show damon yessir
    damon "\"That thing must be really special.\""

    show damon lookside
    show elliot talkside
    elliot "\"Of course it is. It was given to us personally by our goddess, Lumina.\""
    
    show elliot lookside
    show damon neutral
    show side dante question onlayer dante
    dante "\"Lumina??\""

    show side dante neutral onlayer dante
    show damon lookside
    show elliot talk
    elliot "\"Yes. When she created our world, she gave us these crystals that allowed us to perform miracles and command the elements around us.\"" 

    elliot "\"But suddenly, most of the magic was drained from the crystals. Monsters started to appear and went on a rampage as people cried out to her.\""

    elliot "\"Even when the beasts had taken their last victim, she still didn’t answer their cry. At least that is what I was told as a child.\""
    show elliot lookside

    menu:
        "\"I don't believe in that kind of story...\"":
            show elliot neutral
            elliot "..."
        "\"That's an interesting legend...\"":
            show elliot neutral
            elliot "..."
        "\"That's a very long story...\"":
            show elliot neutral
            elliot "..."
    
    show damon yessir

    damon "\"Why are you telling us this?\""

    show damon lookside
    show elliot talk
    elliot "\"Because, what I am requesting is that you find the leyline for me.\"" 
    
    elliot "\"Those same monsters are bringing terror on to small villages and towns. The only means of defense against these monsters is magic...\""

    elliot "\"But it is slowly dying. As for the other leylines, they are either owned by other nobilities or stolen by evil people.\""

    elliot "\"I am asking this of you, so that I can provide people a chance at a future.\""
    
    elliot "\"Many people have already lost their lives to these creatures. People have lost their loved ones to the jaws of these beasts, including me.\""

    show elliot lookside
    show damon yessir
    damon "\"But why him? Why my brother? Why not one of the mages?\""

    show damon lookside
    narrator "Damon questioned his \"offer\", as he found it absurd that he was asking a child — much less his brother, to do this request. Why not ask an experienced mage instead?"
    
    show elliot talk
    elliot "\"I figured you would ask this, and I understand your concerns. See, here is what makes you different from the mages, young man.\"" 
    
    elliot "\"While their magic is inherited through birth, yours was gained through the leyline itself.\""

    elliot "\"The magic that the mages possess has lost its connection to the leyline itself, preventing them from locating the leyline. But you still have that connection.\""

    elliot "\"Which naturally makes you the perfect candidate for this task.\""

    show damon neutral
    show elliot neutral
    show side dante question onlayer dante
    dante "\"So you want me to go in the caves and find this leyline? What’s in it for us? What do we get as a reward?\""
    
    show side dante determined at grab onlayer dante
    narrator "Damon nudges Dante’s side with his elbow, not wanting to present as rude, Dante winces a bit as he glares at him momentarily before looking back at Elliot."
    
    show side dante neutral onlayer dante
    show damon lookside
    show elliot talk
    elliot "\"Oh, of course. I wouldn’t demand such a task without any form of reward. A treasure chest’s worth of gold and jewels.\""

    elliot "\"I am certain that this compensation is more than enough to live out your lives comfortably.\""

    show side dante shocked onlayer dante
    show damon yessir
    show elliot happy
    narrator "Dante and Damon’s jaws dropped; they couldn’t believe this, that much? They must be really desperate for that ore. But as tempting as the offer was, the brothers were considering declining the offer." 

    show side dante neutral onlayer dante
    show damon neutral    
    narrator "Truthfully, what were they gonna do with the money? As much as it could clear his and Damon’s debt, the warden would still not let them go." 
    
    narrator "As vain and conceited the warden was, he was just as greedy. He would have snatched the reward like he deserved it. It’s practically why his office looked very fancy. You could mistake it as a duke’s office."

    show damon yessir
    show elliot lookside
    damon "\"While it is tempting, We’ll have to decline your offer.\""
    
    show damon lookside
    show elliot talkside
    elliot "\"Oh, is my offer still not enough? I understand you have reservations, but I just want you to know that what you possess is something that could truly help us.\"" 
    
    elliot "\"So, please. Along with my compensation, what else is it that you want? We are living in mad times, and you have better chances in finding the leyline.\""

    show elliot lookside
    narrator "Before Dante can speak, Damon interrupts him abruptly." 
    
    show damon yessir
    damon "\"I’m sorry, can I speak with my brother for a moment?\""

    show damon lookside
    show elliot talkside
    elliot "\"Why of course.\""

    hide elliot with dissolve
    show damon neutral at nighttint with moveinleft:
        xzoom 1
        xalign 0.5
    narrator "When Damon is excused, he brings Dante into the far corner of the office."
    
    show side dante question onlayer dante
    dante "\"What are you doing? We have to accept this offer. We can ask for freedom, Damon. No more putting up with the warden’s demands!\""
    
    show side dante neutral onlayer dante
    show damon talkneutral
    damon "\"I know, but are you really okay with taking an offer where you could practically die? You’re not even that experienced yet, Dante.\""

    damon "\"This expedition takes place in the more dangerous parts of the cave, maybe much farther away from here.\""
    
    show side dante talk onlayer dante
    show damon neutral
    dante "\"I know, and I’m willing to take that risk if that means we can be free.\""

    show side dante neutral onlayer dante
    narrator "Damon thinks over what he says and whispers something in Dante's ear. Dante nods and goes over to the older man."
   
    show damon neutral at nighttint with moveinleft:
        xalign 0.1
        xzoom -1
    show elliot happy at nighttint with dissolve:
        xalign 1.2
    show side dante talk onlayer dante    
    dante "\"I accept on the condition that my brother is included in the task as the leader of the expedition.\""

    dante "\"As for the reward, I want us to be free. Free from this place entirely.\""

    show side dante neutral onlayer dante
    show damon lookside
    show elliot talk
    elliot "\"Of course. As long as you complete the task, any method is permitted.\""
    
    hide elliot
    hide damon
    hide side dante neutral onlayer dante
    with dissolve

    scene bg black with fade
    narrator "With that, the brothers went on to form their expedition group and prepare their supplies for the trip tomorrow, with the hope for freedom running in their minds." 
    
    narrator "It wasn’t easy to find members that were willing to take a rookie in their expedition, but they found a good group of people to assist them in their task."

    narrator "As they drift to sleep, they can't help but be excited at the chance to be finally free. They can finally do the things they want to do, without an annoying warden in their ears every minute."
    jump Chapter_4