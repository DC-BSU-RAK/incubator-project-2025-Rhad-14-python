label Prologue:
    stop music
    
    show bg black with fade 
    
    play music "<volume 0.7>audio/wondernew.ogg"
    $ renpy.movie_cutscene("images/intro.webm")
    
    with fade 
    
    scene bg black with fade

    # Warden talking
    warden "\"Move your lazy asses out of bed and get ready to do your tasks!\""
    
    scene barracks-day with fade
    play sound "audio/bell.ogg" volume 0.5
    narrator "The sound of the bell and the warden shouting wakes up the little children from their beds as they go to work, including Dante, the youngest runt of the fray. He goes to the basin to brush his teeth."

    stop sound fadeout 1.0
    show warden shout at daytint with dissolve
    warden "\"Come on! I don't have all day.\""
        
    show warden neutral
    narrator "The warden goes into the barracks and starts to drag the children out the door one by one, but loses his balance a little in the process."
        
    show warden sweat at trip
        
    $ renpy.pause(1.5)
        
    show warden neutral
    show side dante chuckle at daytint, chuckle, left onlayer dante with dissolve
        
    narrator "Dante chuckles a little, hoping the warden doesn’t notice."
        
    show side dante shocked onlayer dante
    show warden sneer
    narrator "But the warden saw him and grabbed his arm."    

    show side dante scared onlayer dante at grab, daytint
    show warden neutral
    dante "..!"# turn this into -----

    show side dante sad onlayer dante
    show warden question
    warden "\"What's so funny?\""

    warden "\"What's so funny that you chuckle, rather than work?\""

    menu:
        "\"You must be hearing things....\"":
            show warden sneer
            warden "\"Don’t lie to me, brat. My ears are vigilant,  I heard you and your stupid laugh. Do you have me out as a fool?\""
            warden "\"Don't undermine me, slave. Who gave you the right to insult me?\""
            show warden shout
            show side dante question onlayer dante
            warden "\"You are lesser compared to me! You are as valued as garbage...\""
            show warden question
            show side dante sad onlayer dante
            warden "\"Do I have to instill that into that miniscule head of yours?\""
            
        "\"Get your hands off me...\"":
            show warden sneer
            warden "\"Don't undermine me, slave. Who gave you the right to insult me?\""
            show warden shout
            show side dante question onlayer dante
            warden "\"You are lesser compared to me! You are as valued as garbage...\""
            show warden question
            show side dante sad onlayer dante
            warden "\"Do I have to instill that into that miniscule head of yours?\""

        "*You silently glare at him in contempt*":
            show warden sneer
            warden "\"Don't undermine me, slave. Who gave you the right to insult me?\""
            show warden shout
            show side dante question onlayer dante
            warden "\"You are lesser compared to me! You are as valued as garbage...\""
            show warden question
            show side dante sad onlayer dante
            warden "\"Do I have to instill that into that miniscule head of yours?\""

    narrator "Before he could lay a finger on Dante, a boy came in to stop the commotion."

    show side dante talk onlayer dante

    # Damon talking
    Dname "\"Hold on there!\""

    show warden lookside with moveinright:
        xalign 1.0
    show damon yessir at daytint with dissolve:
        xzoom -1
        xalign 0.1
    show side dante happy onlayer dante
    damon "\"No need to be so rough on my brother, sir. He's just a boy.\""

    show side dante question onlayer dante
    show damon lookside 
    show warden talkside
    warden "\"Well this boy chuckled when I tripped. I wouldn't even be suprised if he was the one who made me trip in the first place.\""
        
    show warden lookside
    show side dante neutral onlayer dante
    show damon yessir
    damon "\"Sir, I would like to say that this place is quite old, the boards are.\""

    show warden neutral
    show damon neutral

    narrator "The warden looks at you up and down with a scowl on his face as he scoffs."

    show warden talk
    warden "\"Fine, you runts are lucky I'm in a good mood, but remember this, I'm someone who—If you aren't wide-eyed the next time I call you in, you might as well be monster food!\""
        
    show warden shout
    warden "\"Alright, you slugs! Make yourselves useful and get to work.\""

    show damon lookside
    show warden point zorder 2
    warden "\"And you...\""

    #The warden points at Damon.
    show warden talkside
    warden "\"Since you care so much for these runts, you teach all the newbies how things run around here.\""

    show damon yessir
    show warden lookside
    damon "\"Sir, yes sir.\""

    hide warden neutral with dissolve
    show damon happy at daytint with moveinright:
        xzoom 1
        xalign 0.5

    show side dante sigh onlayer dante
    narrator "The warden leaves for his office to do his work. As soon as the warden is out of his sight, Dante lets out a sigh of relief."

    show side dante talk onlayer dante

    dante "\"If it weren't for you, I would have been meal for the monsters.\""

    show side dante happy onlayer dante
    show damon talk
    damon "\"Don't worry about it, anyways. I'll be heading out first to guide the rookies.\""

    show side dante question onlayer dante
    show damon happy
    dante "\"You don't have to listen to that old toad, Damon. Besides, isn't that someone else's job?\""

    show side dante happy onlayer dante
    show damon sigh
    damon "\"I don't mind. Besides, I couldn't just stand by and let him bully you.\"" #this will be animated remove sigh
        
    hide side dante neutral onlayer dante
    hide damon
    with dissolve
    scene damonheadpat with fade:
        subpixel True
        xalign 0.5 yalign 0.5
        zoom 1.0
        linear 5 zoom 1.03

    narrator "Damon ruffles his brother's already messy hair as he sets off to teach the rookies."
    jump Chapter_1