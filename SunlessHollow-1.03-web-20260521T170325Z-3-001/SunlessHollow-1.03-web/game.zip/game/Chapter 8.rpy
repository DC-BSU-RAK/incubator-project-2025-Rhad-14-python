label Chapter_8:
    narrator "Dante's eyes went wide."

    play music "audio/phrase2a.ogg" volume 0.85
    dante "\"DAMON!\""

    narrator "He didn't even think. He just ran, sprinting across the chamber and throwing his arms around his brother in a tight hug."

    narrator "Damon stumbled back a step but hugged him just as hard."

    show damon struggle at leylinetint with dissolve
    damon "\"Dante! You're alive!\""

    show damon struggleclose
    show side dante sad onlayer dante
    dante "\"I thought- I thought you were-\""

    narrator "Damon pulled back just enough to look him over, hands gripping his shoulders."

    show damon struggle
    damon "\"You okay? Hurt anywhere?\""

    show damon struggleclose
    narrator "Dante shook his head, still grinning like an idiot with tears in his eyes."

    show side dante talk onlayer dante
    dante "\"N-no, I'm fine! You won't believe what happened! After the fall, I woke up in this weird place with all the plants and stuff, and I found this-\""

    narrator "He started pulling the pendant out from under his shirt to show it off."

    dante "\"-and it just led me here! Like a compass!\""

    dante "\"And I left marks the whole way so you could-\""

    show side dante shocked at grab onlayer dante
    narrator "Damon grabbed his wrist, cutting him off."

    show damon struggle
    damon "\"Dante. Stop.\""

    narrator "Dante blinked."

    show damon struggleclose
    show side dante question onlayer dante
    dante "\"...What?\""

    narrator "Damon glanced over his shoulder at the massive glowing vein, then back at his brother. His face was serious."

    show side dante neutral onlayer dante
    show damon struggle
    damon "\"We can't give this to Elliot. {w}Or the warden. {w}Or anyone.\""

    show damon struggleclose
    narrator "Dante stared at him."

    show side dante question onlayer dante
    dante "\"What? Why not? This is it! The leyline! We found it! We can be free!\""

    narrator "Damon shook his head."

    show side dante neutral onlayer dante
    show damon struggle
    damon "\"No. Listen to me. After the collapse, I landed in that same weird area. I had no supplies, and my leg was messed up bad. I thought that was it.\""

    show damon struggleclose
    narrator "He pointed toward a darker corner of the chamber."

    show damon struggle
    damon "\"But these crystals…This place… it kept me alive. The only reason I am somewhat okay is that this place has food, water, even herbs to treat some of my wounds.\""

    damon "\"Did you ever wonder why there were biomes thriving in this part of the cave? Why there were clean sources of water? Why there were plants thriving — even producing a lot of ripe fruit?\""

    show damon struggleclose
    narrator "He nodded toward the vein."

    show damon struggle
    damon "\"This ore doesn’t just grant magic, Dante. It's also a source of life here, allowing biomes like these to thrive well despite it being impossible.\""

    damon "\"If we rip it out, all of this dies. And who knows what happens up top. I truly believe Elliot means well, but what if we make the world even worse than it is now?\""

    show side dante talk onlayer dante
    show damon struggleclose
    dante "\"But... The deal. The gold. Freedom-\""

    show side dante neutral onlayer dante
    show damon struggle
    damon "\"Freedom won't mean anything if the world's falling apart. We can't do it.\""

    show damon struggleclose
    narrator "Dante opened his mouth to argue, then closed it again."

    narrator "He looked at the vein. The way it pulsed, steady and alive. The warmth still buzzing in his chest from being so close."
    
    show damon struggle
    damon "\"Think about it. Why do you think that camp back there was empty? They probably came for the same thing. And look what happened to them.\""

    show damon struggleclose
    show side dante talk onlayer dante
    dante "\"I... But Damon, we-\""

    show side dante scared onlayer dante
    show damon struggle
    play sound "audio/explosion1.ogg" volume 0.3
    show leyline:
        zoom 1.05
        xalign 0.5
        yalign 0.5
    narrator "{b}*BOOM!!*{/b}" with vpunch
    
    play sound "audio/rumble_short.ogg"
    show leyline:
        zoom 1.05
        xalign 0.5
        yalign 0.5
    narrator "{b}*RUMBLE*{/b}" with hpunch

    show leyline:
        zoom 1.05
        xalign 0.5
        yalign 0.5
        easeout 1.0 zoom 1.0
    narrator "The ground shook hard, making cracks on the ground. Dust rained from the ceiling. Dante stumbled back as he avoided falling in the cracks again, arms flailing for balance."

    hide side dante onlayer dante with dissolve
    show damon scream at leylinetint
    damon "\"Dante!!!\""

    hide damon with dissolve
    stop music fadeout 5.0
    narrator "The back of Dante’s head hits against the hard surface of the leyline."

    scene bg white with longdissolve
    play music "audio/lumina_full.ogg" fadein 3.0 volume 0.5
    narrator "His eyes shot wide as light filled his eyes and his world went white."

    narrator "As light fills the boy’s vision, Dante suddenly finds himself in a space filled with endless light, stretching endlessly with no end."

    show side dante question at left onlayer dante with dissolve
    dante "\"Where am I?\""

    hide side dante onlayer dante with dissolve
    narrator "The boy thought, as he makes sense of why the leyline placed him in this strange place. He walks around a bit hoping to find some sort of exit, when a voice cuts him out of his trance."

    Lname "\"My child... you have found my last gift.\""

    narrator "Dante turns around to find a lady in front of him, wondering who she was as he takes in her ethereal appearance."

    narrator "No words can really describe her appearance, in fact he can’t really describe her at all, she stands tall and dignified before him, and her face seems to be completely covered by light itself."

    narrator "But intimidating as she looks, he could still feel the warmth and gentleness from how she spoke, like a mother speaking to her child."

    show side dante question at left onlayer dante with dissolve
    dante "\"Who are you?\""

    hide side dante onlayer dante with dissolve
    narrator "The woman softly chortles as she introduces herself."

    lumina "\"I am Lumina, The Veiled Light and your previously residing Goddess of the world.\""

    show side dante shocked at left onlayer dante with dissolve
    dante "\"Lumina!\""

    narrator "He stumbles back a little in surprise before him. He never thought he would have the chance to gain an audience with a Goddess."

    show side dante question onlayer dante 
    dante "\"Why am I here? I need to get back, my brother needs me.\""

    show side dante neutral onlayer dante
    lumina "\"You are here for a reason, my child. You have been chosen to make a choice that can ultimately change the course of history for humanity.\""

    show side dante question onlayer dante 
    dante "\"A choice?\""

    show side dante neutral onlayer dante
    lumina "\"As you know the story well, I created the world. I provided magic through the crystals, and I have abandoned my children. But it seems that some details have been left out.\""

    hide side dante onlayer dante with dissolve
    scene outside with longdissolve
    narrator "The Goddess suddenly changed the scenery before the little boy, they now stand in what looked like a small forest. Unlike the descriptions that Elliot shared, this forest was green, filled with trees, fauna, and bushes."
    
    narrator "The wildlife, not scary in appearance as the elder gentleman described, roamed freely without a care. Was this a vision of the past?"
    
    lumina "\"After their creation, humans have indeed cultivated and expanded their land.\""

    lumina "\"Making villages, establishing friendships and providing generous support to each other, the people lived on for years in this perfect vision of peace and harmony.\""

    lumina "\"And most important of all, they kept an important rule; never dig out the Leyline, for the magic is to be shared, not only amongst the people, but also to all life around you. But, for a rule so simple to follow, these humans had no problem breaking it...\""

    scene bg white with longdissolve
    narrator "The vision changed to what looks like a king and his army raiding much smaller kingdoms. The cruel king burned their towns, took the riches, and killed villagers in cold blood."

    narrator "The king laughed at the cries of the townsfolk as he sat on his moving throne, while swirling the wine in his golden goblet."

    lumina "\"As years pass, the hearts of some humans have grown cruel and selfish.\""

    lumina "\"They would destroy and enslave towns for riches, take people in as their slaves, and kill others simply because.\""

    lumina "\"I have punished these humans before, hoping this would make them learn. But it only darkened their hearts even further. One day, they committed a sin that would cost their lives...\""

    narrator "The army marched in the city until they reached the center of the kingdom to find its very own leyline. Though it was in a different hue of color, it still shone as brightly as the one in the cave."

    narrator "The vision shows the king commanding his men to dig up the ore for himself."

    lumina "\"A greedy king led a greedy campaign with other kingdoms behind him to gather all the leylines around the land and divide the spoils amongst themselves.\""

    lumina "\"Leaving the bodies of those who dared to stop him, even some of his people were killed in his tyranny.\""

    lumina "\"Other humans have tried to defy the campaign in my name, but they lost their lives to his cruel hand. I have had enough of them. They hoarded the spoils of my creation for themselves and they disobeyed the one rule I imposed on them...\""

    narrator "The scene changes as Dante finds himself under the sky turning red as magic from the crystals were sucked up into the sky, with storm clouds suddenly darkening the sky even further."

    narrator "He hears growls from the forest behind him. The once docile creatures of the forest were now becoming beasts that charged towards him in untamed fury."

    narrator "Dante was about to run but they passed through him instead — forgetting it was a vision, he turns to where they went and he was met with an ungodly sight."

    narrator "The armies were torn up like it was nothing. Their blood stained the grass, and as much as they tried, they were overpowered and killed on the spot."

    lumina "\"I took back the magic they wrongfully took and I bestowed the creatures with my godly rage, commanding them to slaughter the king and his armies.\""

    lumina "\"I made sure to cleanse the world of their cruelty. The king dared to turn to me for protection, but I simply let the creatures bring forth his demise.\""

    lumina "\"The only ones who survived are the ones who fought against him. With this disaster, I decided to leave but not without a farewell...\""

    lumina "\"The leylines will only bestow magic on a select few of people and will also null the rage that I bestowed on the creatures.\""
    
    lumina "\"For this time, I left with the intention to have the humans thrive on their own. I thought that without me, they would finally do better. But once again I was wrong...\""

    narrator "Visions of people committing acts of cruelty and selfishness flash one by one, showing that some people never changed."

    lumina "\"History simply just repeated itself and worst of all, they are uprooting the leylines again, leaving the world dying.\""

    lumina "\"There were almost no leylines left except the one in this very cave. It was almost taken, but a brave human came to preserve it — even fighting his former allies for its sake...\""

    narrator "The vision shows a miner touching the crystal and shards of the leyline sprouted out of the ground, intending to stop his former team."

    narrator "Some injured them, and some killed them instantly, Dante suddenly recognizes the miner as the skeleton with the pendant back in the hole he fell through."

    narrator "The action of the miner drained his energy, but he still had strength to go and seal the entrance of the cavern with his pendant as the key."

    narrator "It shows him trying to return to the barracks, leaving one last message in his journal as he headed through the tunnels to get back to the surface."

    narrator "Unfortunately, he succumbs to his wounds after he sat down with his back resting against the wall."

    show side dante question at left onlayer dante with dissolve
    dante "\"So what exactly do you want from me?\""

    hide side dante onlayer dante with dissolve
    lumina "\"Because of the child’s sacrifice, his magic is allowing this leyline to expand and spread, allowing the chance for new leylines to take root.\""

    lumina "\"If people interfere and uproot the last leyline — the land will die, the creatures will go rampant, and all order will be lost.\""

    lumina "\"You have a choice. Either take the deal and be free with your brother and companions, or choose to protect the crystal for the betterment of your future...\""

    lumina "\"Choose wisely…\""

    stop music fadeout 6.0
    scene leyline with longdissolve
    narrator "Dante gasped as the white light shattered."

    play sound "audio/explosion1.ogg" volume 0.3
    scene leyline:
        zoom 1.05
        xalign 0.5
        yalign 0.5
    narrator "{b}*BOOM!!*{/b}" with hpunch

    scene leyline:
        zoom 1.05
        xalign 0.5
        yalign 0.5
        easeout 1.0 zoom 1.0
    narrator "An explosion rocked the chamber. Shouts echoed from the tunnel behind Damon."

    narrator "Dante blinked, still dazed, hand still pressed to the crystal."

    show damon scream at leylinetint with dissolve
    damon "Dante, what was that?!"

    hide damon with dissolve
    play music "audio/danger_mid.ogg" fadein 3.0 volume 0.5
    narrator "Through the dust and smoke pouring in from the entrance..."
    
    narrator "The warden."
    
    narrator "He stood at the head of a group of armed miners and mages, torches and lanterns lighting up their grim faces. Behind them, more shadows moved."
    
    show warden smug at leylinetint with dissolve
    warden "Well, well. The little rat actually found it."
    
    narrator "Dante felt his heart drop to his stomach."
    jump Chapter_9