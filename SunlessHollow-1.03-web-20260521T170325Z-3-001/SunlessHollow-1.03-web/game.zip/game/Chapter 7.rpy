label Chapter_7:
    if read_journal:
        narrator "Dante steps out of the camp with a bit of a chill under his skin."

        narrator "One thing is clear. Whoever the author was, they were adamant on preserving the crystal. Even if that meant getting rid of his companions. It's as if this cave was warning him to stop and go back to the camp."
        
        narrator "He's already gone this far, and he’s not going to let some warning from a dusty journal stop him. Besides, his brother was still out there too. He won’t rest until he finished what he started."
    
    else:
        narrator "Dante steps out of the camp with a bit of chill under his skin."
        
        narrator "Whatever happened to the people in the camp, it was certain that they were after the leyline as well. And this cave was making sure no one came out alive for even trying."
        
        narrator "He's already gone this far, and he’s not going to let some warning from a dusty journal stop him. Besides, his brother was still out there too. He won’t rest until he finished what he started."

    dante "\"Just a little further... I gotta find him.\""

    scene tunnel-2 with fade
    narrator "Dante treads on further into the cave, determined to finish this and take the reward for the team."

    narrator "He thinks of the many things that he could do with the reward once he left the place. The idea did cross his mind, but he never really thought it out properly."

    narrator "Maybe they could buy a house outside a small village and settle. Open a small inn for adventurers alike and invite their team for a drink. Or maybe even travel across the world."

    narrator "The possibilities were endless. And with every step he took, he couldn’t help but dream a bit. It’s surreal that they could be free of everything. All Dante had to do was to find the crystal and his brother."

    narrator "Before he left the camp area, he left another sign for his brother. This time, he pulled out the old pinboard from the messy tent. He pinned unused paper on it, writing out in big letters."

    narrator "{i}I WAS HERE, GO THIS WAY\n\n-DANTE{/i}"

    narrator "He finished by making an arrow with some sticks, pointing at the direction where he'd go. He then sets off to find the leyline."

    narrator "..."

    narrator "Time passes on as he traverses through the tunnels, stopping every now and then to rest and leave more signs for his brother to find."

    narrator "The further he goes, the tunnel gets narrower, winding through more roots and glowing mushrooms — continuing to follow the beam of light the pendant emitted."

    narrator "The further he went, the more the tunnel sloped downward. The air got thicker, heavier with that strange magic feeling. Crystals poked out from every crack, some small, some as big as his head."

    narrator "After what felt like hours, the pendant’s beam stopped at a wall."

    narrator "Dante looks around the wall, hoping there was some opening or a crack he could squeeze through. As he looked around, the pendant glowed brighter — an archaic symbol appearing and opening the wall before him."

    narrator "No wonder they wanted to take the compass far away from here. It also acted as a magic key."

    dante "\"No way...\""

    scene tunnel-3 with fade
    stop music fadeout 5.0
    narrator "Beyond the doorway, the tunnel glowed. Crystals lined every surface, bigger and brighter than any he'd seen so far. They pulsed in rhythm, like the whole place was alive."

    play music "audio/phrase2b.ogg"
    narrator "He stepped inside."

    narrator "Skeletons could be found lying around random places on the path. Some were by the wall, and some were sprawled on the floor, with tools scattered nearby. Whoever they were, they only made it this far."

    narrator "Dante swallowed hard and kept walking, his eyes locked on the pendant."

    narrator "The tunnel wasn't long. After just a few turns, it opened up."

    stop music fadeout 2.5
    narrator "And there it was."

    scene leyline with fade
    play music "audio/grand_loop_final2.ogg" volume 0.2 fadein 2.0
    narrator "The leyline vein."

    narrator "Dante froze."

    narrator "It filled the entire chamber ahead — a massive, throbbing heart of crystal with roots of glowing blue stone twisting through the rock like arteries."

    narrator "Spikes of pure crystal jutted out everywhere, shimmering with inner light. The air hummed with power, the weight of it pressing on his chest."

    show side dante talk at left, leylinetint onlayer dante with dissolve
    dante "\"...That's it. That's really it.\""

    hide side dante onlayer dante with dissolve
    narrator "The pendant went dead silent, hanging dim against his chest."

    narrator "But the spark inside him? It was pulling him closer to the source, like a moth to a flame."

    narrator "Heat rushed through his arms, his hands, and his fingertips. Something started flowing through him, it made him feel lively — powerful, even."

    narrator "Without thinking, he snapped his fingers."

    narrator "A small flame sparked to life in his palm, dancing for a second before flickering out."
    
    show side dante shocked at left, leylinetint onlayer dante with dissolve
    dante "\"What the-  Did I do that?!\""
    
    hide side dante shocked onlayer dante with dissolve
    narrator "The sudden flame startled him as he rapidly shook his hand to put out the flame. He was enamoured at the sudden burst of magic."

    narrator "The fact that he could conjure a flame from the just the palm of his hand was a sight for sore eyes."

    show side dante talk at left, leylinetint onlayer dante with dissolve 
    dante "\"Elliot was right. This COULD change everything...\""

    if read_journal:
        narrator "But as he stared at the glowing heart of crystal, that journal entry flashed back in his mind."

        narrator "\"...The leyline vein should not be mined. Leave it alone if you want to preserve what little peace this world has...\""

        show side dante sad onlayer dante
        narrator "Dante frowned."
               
        dante "\"Why were they so against it? What did they mean by 'little peace'?\""
    
    stop music fadeout 6.0
    hide side dante sad onlayer dante with dissolve
    narrator "The chamber felt too quiet now. It was too perfect. The leyline sat untouched."

    narrator "It felt too easy. Surely there had to be something that would keep him from going any further."

    narrator "Then-"

    Dname "\"STOP!\""

    stop music
    narrator "The shout echoed through the chamber. Dante spun around, heart jumping into his throat."

    narrator "Standing at the tunnel entrance, dusty and bruised but alive—"

    narrator "Dante’s eyes widened, as he caught a glimpse of a familiar figure."

    narrator "His brother."

    narrator "Damon."

    show side dante scared at left, leylinetint onlayer dante with dissolve
    jump Chapter_8