label Chapter_11_Step_aside:
    narrator "One final pull of magic, and they ripped the crystal's core free."
    
    narrator "The chamber went quiet for a split second."
    
    narrator "The warden stepped toward the freshly uprooted leyline as he broke off a piece to examine."
    
    narrator "The small shard was much dimmer in light, but it still glowed its blue hue in the palm of his hand. He had a huge grin plastered on his face."

    show warden smug at leylinetint with dissolve
    warden "\"It's all mine...\""

    hide warden with dissolve
    narrator "Then everything changed."

    show leyline at caveshake
    init python :
        renpy.music.register_channel("rumblefx", mixer="sfx", loop=True)
    play rumblefx "audio/rumble.ogg" volume 0.5 fadein 0.3
    narrator "The cave trembled once again as they heard something coming from another tunnel. The sound becomes louder as the threat comes closer. Damon gets up quickly to grab his brother."

    show damon scream at leylinetint with dissolve
    damon "\"We need to leave now!\""

    hide damon with dissolve
    narrator "Then, chaos erupted."

    narrator "Everyone immediately started to run towards the entrance they came from."

    narrator "The warden's face went pale, but he proceeded to escape along with the others, shoving another mage who was in his way."

    show warden shout at leylinetint with dissolve
    warden "\"Out of my way! Take the leyline and the remaining crystals.\""

    hide warden with dissolve
    narrator "The mages use their magic to transport the crystal's core out of the cave, with some of the miners gathering the smaller parts of the ore."

    narrator "But Damon saw it happen. Even with his injuries, he dragged himself up and limped toward the warden."

    show damon scream at leylinetint with dissolve
    damon "\"No! Put it down! We need to return the crystal while we still can!\""

    hide damon with dissolve
    narrator "The warden kicked him away hard. Damon hit the ground and coughed, blood on his lips, but he kept reaching."

    show damon struggle at leylinetint with dissolve
    damon "\"Dante... Stop him... Everything will fall apart...\""

    hide damon with dissolve
    narrator "Everything that breathed life in the cave began to die with every second. Every tree, every plant, even the water dried up. Everything was slipping away before their very eyes."

    narrator "But Dante simply turned his head away."

    narrator "As the crystal flickered in the warden's hands, it brushed itself on a mage, with the magic spreading fast. The leyline only grants true magic to a select few, and it seems that the mage was not one of them."

    narrator "Magic started to seep through his veins at an alarming rate, causing him to double back in pain and drop his staff, screaming in agony at the shot of pain."

    narrator "Another mage screamed as the undeserved magic consumed their arm. Another tried to run but collapsed twitching on the ground. Soon, other mages and miners fell back and screamed at the flow of magic in their veins."
    
    show warden talk at leylinetint with dissolve
    warden "\"What is-\""

    hide warden with dissolve
    narrator "The cave began to collapse again as the ground tore itself apart. Many who came in contact with any of the leyline shards were writhing and convulsing on the ground at the overwhelming flow of magic."

    narrator "To make things worse, the sounds of monsters were coming closer."

    show warden lookside at leylinetint:
        xalign 1.0
    show damon struggleside at leylinetint:
        xzoom -1
        xalign -0.10
    with dissolve
    damon "\"You need to return the leyline!\""
    
    narrator "Damon takes the staff of one of the mages and uses it to drag the ore back to its original place. However, the warden catches him in the act and he was quick to wrestle the staff out of his hands."

    show warden shoutside
    show damon strugglecloseside
    warden "\"Don’t you take it, it’s mine to claim, you hear me! Mine!\""

    show warden lookside
    show damon struggleside
    damon "\"Can’t you see? It’s killing everyone around you!\" "

    show warden shoutside
    show damon strugglecloseside
    warden "\"Back off!\""

    hide damon 
    hide warden 
    with dissolve
    narrator "He pushes the injured boy, knocking him back to the hard surface of the wall. Dante rushes to his side, dropping the pendant in the process."

    narrator "The warden picks it up as he takes the leyline with him, using the magic from the staff to move the giant ore."

    narrator "Damon watched from the ground, too weak to move, blood dripping from his mouth. Dante checked on him."

    show damon struggle at leylinetint with dissolve
    damon "\"Dante... it's too late...\""
    
    narrator "He weakly pointed behind him. Dante looked at the direction he pointed at, seeing the warden leaving the cave with the ore and his pendant."

    narrator "Dante subconsciously reaches for his neck for the pendant, but realized the warden must have taken it in the chaos."
    
    stop rumblefx fadeout 6.0
    hide damon with dissolve
    scene bg black with fade
    stop music fadeout 4.5
    narrator "Things took a turn for the worse when the monsters arrived."

    narrator "They burst into the chamber from every tunnel, with eyes glowing red, and claws scraping stone. They resembled the creatures in the visions that Lumina showed him."

    narrator "The beasts charged and the first mage who went down screaming as a beast tore into them. Then another. Blood kept on splattering the walls."

    narrator "The warden vanished into the shadows of the entrance tunnel, not before sealing the door with the pendant. Everyone was left to deal with the collapsing cave and the incoming danger of monsters."

    narrator "Dante watched on as everyone before him was getting slaughtered by monsters, or falling through the cracks of the cave. He was cheated, and soon, he will be nothing more than just a casualty to the horrors of this cave."

    narrator "What would have happened if he protected the crystal?"

    narrator "Who knows?"

    narrator "The warden had escaped with his prize."

    narrator "And the world above would pay for it."
    $ unlock_achievement("You achieved the bad ending. (3/3)") 
    play music "audio/soft_full.ogg" volume 0.2
label credits:
    $ quick_menu = False
    scene credits-scene with fade
    pause
    scene bg black with longfade
    return