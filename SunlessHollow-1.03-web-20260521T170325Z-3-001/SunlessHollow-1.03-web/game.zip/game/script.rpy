﻿#region Variables
#AUDIO
init python:
    
    def b(event, **kwargs):
        if event == "show":
            renpy.sound.play("audio/bad.ogg", relative_volume = 0.1, channel= "sound", loop=True)
        elif event == "slow_done" or event == "end":
            renpy.sound.stop(channel="sound")
    def g(event, **kwargs):
        if event == "show":
            renpy.sound.play("audio/good.ogg", relative_volume = 0.1, channel= "sound", loop=True)
        elif event == "slow_done" or event == "end":
            renpy.sound.stop(channel="sound")

#WARDEN
define warden = Character("Warden", image="warden", callback=b)
image warden neutral:
    "warden neutral.png"
    zoom 1
    yalign -0.1
    xalign 0.5
image warden lookside:
    "warden lookside.png"
    zoom 1
    yalign -0.1
#warden anim
image warden scanning:
    "warden lookside.png"
    pause 1.5
    "warden neutral.png"
image warden sneer:
    "warden sneer.png"
    zoom 1.0
    yalign -0.1
    xalign 0.5
image warden sweatside:
    "warden sweatside.png"
    zoom 1.0
    yalign -0.1
image warden smug:
    "warden smug.png"
    zoom 1.0
    yalign -0.1
    xalign 0.5
image warden shout:
    "warden shout.png"
    zoom 1.0
    yalign -0.1
    xalign 0.5
image warden question:
    "warden question.png"
    zoom 1.0
    yalign -0.1
image warden sweat:
    "warden sweat.png"
    zoom 1.0
    yalign -0.1
image warden talkside:
    "warden talkside.png"
    zoom 1.0
    yalign -0.1
image warden talk:
    "warden talk.png"
    zoom 1.0
    yalign -0.1
    xalign 0.5
image warden point:
    "warden point.png"
    zoom 1.0
    yalign -0.1
image warden scared:
    "warden scared.png"
    zoom 1.0
    yalign -0.1
    xalign 0.5
image warden shoutside:
    "warden shoutside.png"
    zoom 1.0
    yalign -0.1

#DANTE
define dante = Character("Dante", image="dante", callback=g)
image side dante neutral:
    "side_dante_neutral.png"
    zoom 0.5
image side dante chuckle:
    zoom 0.5
    "side_dante_chuckle.png"
    pause 0.75
    "side_dante_happy.png"
image side dante happy:
    "side_dante_happy.png"
    zoom 0.5
image side dante determined:
    "side_dante_determined.png"
    zoom 0.5
image side dante talk:
    "side_dante_talk.png"
    zoom 0.5
image side dante question:
    "side_dante_question.png"
    zoom 0.5
image side dante scared:
    "side_dante_scared.png"
    zoom 0.5
image side dante sad:
    "side_dante_sad.png"
    zoom 0.5
image side dante determinedtalk:
    "dante determinedtalk.png"
    zoom 0.5
image side dante sigh:
    zoom 0.5
    "side_dante_neutral.png"
    pause 1.5
    "side_dante_sigh.png"
    pause 1
    "side_dante_happy.png"
image side dante sigh_alt:
    zoom 0.5
    "side_dante_sad.png"
    pause 0.75
    "side_dante_sigh.png"
    pause 1
    "side_dante_neutral.png"
image side dante shocked:
    "side_dante_shocked.png"
    zoom 0.5
image side dante sigh_alt2:
    zoom 0.5
    "side_dante_neutral.png"
    pause 0.5
    "side_dante_sigh.png"
    pause 0.89
    "side_dante_talk.png"

#DAMON
define damon = Character("Damon", image="damon", callback=g)
image damon happy: 
    "damon happy.png"
    zoom 1
    yalign -0.1
    xalign 0.5
image damon lookside:
    "damon lookside.png"
    zoom 1
    yalign -0.1
    xalign 0.5
image damon grin:
    "damon grin.png"
    zoom 1.0
    yalign -0.1
    xalign 0.5
image damon neutral:
    "damon neutral.png"
    zoom 1.0
    yalign -0.1
    xalign 0.5
image damon scaredside:
    "damon scaredside.png"
    zoom 1.0
    yalign -0.1
    xalign 0.5
image damon sigh:
    zoom 1.0
    yalign -0.1
    xalign 0.5
    "damon sigh.png"
    pause 1.0
    "damon happy.png"
    pause 0.8
    "damon talk.png"
image damon yessir:
    "damon yessir.png"
    zoom 1.0
    yalign -0.1
    xalign 0.5
image damon talk:
    "damon talk.png"
    zoom 1.0
    yalign -0.1
    xalign 0.5
image damon talkneutral:
    "damon talkneutral.png"
    zoom 1.0
    yalign -0.1
    xalign 0.5
image damon struggleside:
    "damon struggleside.png"
    zoom 1.0
    yalign -0.1
    xalign 0.5
image damon struggle:
    "damon struggle.png"
    zoom 1.0
    yalign -0.1
    xalign 0.5
image damon struggleclose:
    "damon struggleclose.png"
    zoom 1.0
    yalign -0.1
    xalign 0.5
image damon strugglecloseside:
    "damon strugglecloseside.png"
    zoom 1.0
    yalign -0.1
    xalign 0.5
image damon screamside:
    "damon screamside.png"
    zoom 1.0
    yalign -0.1
    xalign 0.5
image damon scream:
    "damon scream.png"
    zoom 1.0
    yalign -0.10
    xalign 0.5

#ELLIOT
define elliot = Character("Elliot", callback=g)
image elliot neutral:
    "elliot neutral.png"
    zoom 1.15
    yalign 0.1
image elliot disappointed:
    "elliot disappointed.png"
    zoom 1.15
    yalign 0.1
image elliot lookside:
    "elliot lookside.png" 
    zoom 1.15
    yalign 0.1
image elliot talk:
    "elliot talk.png"
    zoom 1.15
    yalign 0.1
image elliot happy:
    "elliot happy.png"
    zoom 1.15
    yalign 0.1
image elliot talkside:
    "elliot talkside.png"
    zoom 1.15
    yalign 0.1
image elliot shout:
    "elliot shout.png"
    zoom 1.15
    yalign 0.1

#ROWAN
define rowan = Character("Rowan", callback=g)
image rowan neutral:
    "rowan neutral.png"
    zoom 1.2
    yalign -0.1
    xalign 0.5
image rowan happy:
    "rowan happy.png"
    zoom 1.2
    yalign -0.1
    xalign 0.5
image rowan grin:
    "rowan grin.png"
    zoom 1.2
    yalign -0.1
    xalign 0.5
image rowan sad:
    "rowan sad.png"
    zoom 1.2
    yalign -0.1
    xalign 0.5
image rowan grinning:
    zoom 1.2
    yalign -0.1
    "rowan grin.png"
    pause 0.8
    "rowan happy.png"

define lumina = Character ("Lumina")

#BACKGROUND CHARACTER
define anne = Character("Anne", callback=g)
define robert = Character("Robert", callback=g)
define gabriel = Character("Gabriel", callback=g)
define amity = Character("Amity", callback=g)
define random_miner = Character("Miner", callback=b)
define bernard = Character("Bernard", callback=g)
define king = Character ("King", callback=b)
define noble = Character ("Noble", callback=b)
define anotherslave = Character ("Another slave", callback=g)
define messenger = Character ("Messenger", callback=g)

define Dname = Character ("???", callback=g)
define Ename = Character ("???", callback=g)
define Rname = Character ("???", callback=g)
define Lname = Character ("???")

transform chuckle:
    linear 0.3 yoffset 8
    linear 0.1 yoffset -6
    linear 0.1 yoffset 4
    linear 0.1 yoffset -6
    linear 0.1 yoffset 0
transform grab:
    linear 0.04 xoffset -10
    linear 0.04 xoffset 10
    linear 0.04 xoffset -8
    linear 0.04 xoffset 8
    linear 0.04 xoffset 0
transform trip:
    linear 0.06 xoffset -4 yoffset 10
    linear 0.06 xoffset 5 yoffset 45
    linear 0.06 xoffset 20 yoffset 20
    linear 0.08 xoffset 0 yoffset 0
transform bite:
    yoffset 0
    easein 0.1 yoffset -20
    easeout 0.1 yoffset 0  
    yoffset 0
transform caveshake:
    zoom 1.05
    align (0.5, 0.5)
    linear 0.1 xoffset -8 yoffset 3
    linear 0.1 xoffset 8 yoffset -3
    linear 0.1 xoffset 3 yoffset -8
    linear 0.1 xoffset -3 yoffset 8
    linear 0.1 xoffset 0 yoffset 0
    repeat #
transform achievement_appear:
    alpha 0.0
    xoffset 50
    linear 0.3 alpha 1.0 xoffset 0
    pause 2.0
    linear 0.3 alpha 0.0 xoffset 50

define longfade = Fade(1.0, 1.0, 2.0)
define longdissolve = Dissolve (2.0)

#Helper
transform daytint:
    matrixcolor TintMatrix("ffc3b6")
transform nighttint:
    matrixcolor TintMatrix("BF8B64")
transform outsidetint:
    matrixcolor TintMatrix("E1D7B9")
transform bluetint:
    matrixcolor TintMatrix("b2b4f5")
transform leylinetint:
    matrixcolor TintMatrix ("#a7f0ff")

default read_journal = False

image splash = "TacSplash.png"
image main = "MainMenu.jpg"
image darkenscreen = Solid("#00000099")

label splashscreen:
    scene bg black with dissolve
    pause (3)

    show splash with dissolve
    pause (2)

    show black with dissolve
    pause (1)

    show main with longfade

    return
#endregion Variables

label start:
    show expression "#000" as background_fill
    jump Prologue

default journal_entries = ""

# Book Journal Part
transform top_middle:
    xalign 0.5
    yalign 0.2

image monsterscene = Composite(
    (1920, 1080), (0, 0), Solid("#000"), 
    (0,0), "monsterscene.webp"
    )

init python:
    def unlock_achievement(text):
        renpy.show_screen("achievement_popup", text=text)
        renpy.pause(3.0)
        renpy.hide_screen("achievement_popup")