label Chapter_1:
    show bg black with longfade
    narrator "..."
    show barracks-day with fade
    play sound "audio/bell.ogg" volume 0.5
    narrator "Dante stirs awake to the sound of the bell again."

    stop sound fadeout 1.0
    narrator "For a second, he thought he was back in that old memory with the warden shouting and insulting him, with Damon getting him out of trouble."

    narrator "But when he sat up, the barracks looked a little different. The beds were the same as well as the stone walls, but the kids around him weren’t as small anymore. Some of them were already getting taller, growing into their shackles."

    narrator "Today was different for him too. Today, he wasn’t just another errand boy."

    narrator "Dante swung his legs off the bed, rubbing the sleep from his eyes. His hands were rougher and calloused now from years of nonstop work."

    narrator "He stretched and headed to the basin to wash his face. The water was cold as always, and it woke him up."

    show side dante sigh_alt at left, daytint onlayer dante with dissolve

    dante "\"Rookie miner.. Hah.. no pressure at all.\""

    hide side dante neutral onlayer dante with dissolve
    narrator "He lets out a weak laugh at himself and splashes more water on his face, trying to distract himself from the nerves sitting in his chest."

    narrator "Outside, the warden's voice echoed through the hallway."

    warden "\"You lot better be ready when I come in there! I better not see anybody dragging their feet!\""

    narrator "Some of the younger kids flinched at the warden's voice, others just moved faster — already used to it."

    narrator "Dante dried his face on his sleeve and started getting dressed in the basic mining gear they were given: a worn shirt, some rough trousers, and a belt that holds their tools for the day."

    narrator "By the time the warden actually stepped into the room, most of them were already standing by their beds."

    show warden talk at daytint with dissolve
    warden "\"Good. At least you know how to stand now.\""

    show warden scanning 
    narrator "The warden’s eyes scanned the room, sharp and judging, but this time he didn’t stop in front of Dante. He just jerked his thumb towards the door."

    show warden talk 
    warden "\"Breakfast. Be there on time, or starve for all I care. Then work. You know the drill.\""

    hide warden with dissolve
    scene messhall with fade
    narrator "They filed out into the corridor, shoulders brushing, chains clinking, as they walked towards the mess area."

    narrator "Once he was there, Dante grabbed a bowl and joined the line. The soup was thin but warm. He took his portion and looked around for a place to sit."

    Rname "\"Dante! Over here!\""
    show rowan happy at outsidetint with dissolve
    play sound "<volume 1.5>audio/happy3.ogg"
    narrator "One of the kids waved him over. It was a boy around his age with a chipped tooth and messy hair. He had grown up in the mines with Dante."

    narrator "Dante sits down across from Rowan, blowing on his soup."

    show rowan grin
    Rname "\"So, today’s the big day huh? Rookie miner Dante!\""

    show rowan grin
    show side dante sigh at left, outsidetint onlayer dante with dissolve
    narrator "The boy grins and Dante sighs."

    show side dante talk onlayer dante
    show rowan happy at outsidetint
    dante "\"Don’t say it like that, Rowan. You’re making it sound like I signed up for this.\""

    show side dante neutral onlayer dante
    show rowan grinning at chuckle
    narrator "Dante grumbles as Rowan lets out a chuckle."

    show rowan grin
    rowan "\"Hey, at least you’re not just running errands for the warden anymore. That’s something, right?\""

    show rowan happy
    show side dante talk onlayer dante
    dante "\"Yeah. ‘Something’...\""

    show side dante neutral onlayer dante
    narrator "He stirs the soup, watching it swirl in the bowl."

    narrator "He remembered what Damon told him the night before."

    narrator "“Don’t overthink it. Just follow instructions, always be alert, and stay away from the monsters. You’ll be fine.”"

    dante "\"Easy for him to say...\""

    show rowan sad
    rowan "\"Are you nervous..?\""

    show rowan happy
    menu:
        "\"A bit, yeah.\"":
            show rowan grin
            rowan "\"Well... Damon’s the one teaching today, right? You’re lucky. If anyone can keep the rookies alive, it’s him.\""
        
        "\"Not really. I've seen worse.\"":
            show rowan grin
            rowan "\"Well... Damon’s the one teaching today, right? You’re lucky. If anyone can keep the rookies alive, it’s him.\""

        "\"Doesn't matter how I feel. Still have to go.\"":
            show rowan grin
            rowan "\"Well... Damon’s the one teaching today, right? You’re lucky. If anyone can keep the rookies alive, it’s him.\""

    show rowan happy
    show side dante happy onlayer dante
    narrator "At the mention of his brother, Dante relaxes a little and becomes less tense."

    show side dante talk onlayer dante
    dante "\"Yeah. I guess that’s true.\""

    hide side dante neutral onlayer dante
    hide rowan
    with dissolve
    narrator "They finished waiting for the call, when the wardens walked between the tables — tapping their batons on the wood."

    warden "\"Eat faster! We aren’t running a tavern here!\""

    scene mine-entrance with fade
    narrator "Soon after, they were herded outside towards the mine entrance. The tunnels loomed ahead, dark and familiar."

    narrator "But this time, Dante wasn’t just passing things around. He would be going in with a pickaxe in hand."

    #bg cave mining spot
    narrator "At the entrance, Damon was already waiting with a small group of miners. He wore the same rough clothes as everyone else, but he somehow made them look like a uniform instead of slave rags."

    show damon talk at nighttint with dissolve
    damon "\"Rookies! Over here!\""

    show damon happy
    narrator "Dante joined the group, standing a little straighter when Damon’s eyes met his. For a second, it was just like the old days. The two of them against the world."

    narrator "Dante snapped out of his thoughts when Damon clapped his hands to get everybody’s attention."

    show damon talk 
    damon "\"Alright listen up. You’re all old enough now, so you’ll be mining like the rest of us. That means more responsibility, more danger, and more chances to mess up. So pay attention and you’ll be fine.\""

    show damon happy
    narrator "Damon points to a spot near the open tunnel."

    show damon talk
    damon "\"First rule: You never swing your pick without checking what’s around you. We don’t want any missing fingers or broken skulls, so keep your eyes open and pay attention to your surroundings.\""
    
    hide damon with dissolve
    narrator "He walked them through the basics: where to strike the rock, how to tell if a piece of ore was worth picking up, when the support beams looked weak, and where not to step when the ground started to crack."

    narrator "Dante followed carefully, trying to memorize each bit. His palms were sweating around the handle of his borrowed pickaxe. At one point, Damon stood next to him and lowered his voice."
    
    show damon talkneutral at nighttint with dissolve
    damon "\"Hey.. you doing okay?\""

    show damon neutral
    narrator "Damon looks down at Dante with concern."

    show side dante neutral at left, nighttint onlayer dante with dissolve
    menu:
        "\"Uh- yeah. Just.. taking it all in.\"":
            show damon happy
            narrator "Damon gives Dante a small reassuring smile."
        "\"I don't want to mess up in front of you.\"":
            show damon happy
            narrator "Damon gives Dante a small reassuring smile."
        "\"I'll be fine. I've survived worse.\"":
            show damon happy
            narrator "Damon gives Dante a small reassuring smile."

    show damon talk
    damon "\"I’ll be close by. Just focus. You’re not alone in there.\""

    hide side dante neutral onlayer dante
    hide damon
    with dissolve
    narrator "They moved further into the tunnel. The light from the entrance faded, replaced by the glow of lanterns hanging from the hooks in the rock. The air grew cooler and heavier with dust."

    narrator "Another senior miner called out about the monsters, reminding the rookies not to drop everything and run if they hear the warning bells go off."

    random_miner "\"No magic, no heroics. If you see something with too many teeth or too many legs, you get out. Understood?\""

    hide random_miner with dissolve
    narrator "The rookies gulped and nodded in unison."

    narrator "Dante swallowed. He had heard stories about monsters in the deeper tunnels, but he had never seen one up close. He hoped it would stay that way."

    narrator "The day dragged on as Dante worked."

    narrator "He swung his pick, collected small chunks of ore, and carried baskets to the drop-off point. His arms burned by midday, and his back ached from all the bending and lifting."

    narrator "Even so, there were moments when something felt…  off."

    narrator "Once, when he placed his hand on the tunnel wall to steady himself, he thought he saw a faint shimmer under the stone, like a line of light hidden just out of reach. When he blinked, it was gone."

    narrator "Another time, he picked up a piece of ore, and for a split second, he knew it was worthless before anyone even inspected it. He tossed it aside without thinking, then realized he had made the call before checking it like he was told to."

    narrator "Damon noticed this."

    show damon talkneutral at nighttint with dissolve
    damon "\"You sure about that one?\""

    show damon neutral
    narrator "Dante hesitated."

    show side dante talk at left, nighttint onlayer dante with dissolve
    dante "\"I.. just had a feeling it wasn’t any good..\""

    show side dante neutral onlayer dante 
    narrator "Damon eyed him for a moment, then checked the ore himself. He cracked it open and showed the dull, empty inside."

    show damon talk
    damon "\"Huh. Lucky guess.\""

    show side dante happy onlayer dante
    show damon happy
    narrator "Dante forced a smile."

    show side dante talk onlayer dante
    dante "\"Yeah. Lucky.\""

    show side dante neutral onlayer dante
    narrator "But inside he knew it wasn’t just luck."

    narrator "Something in his chest felt like it was buzzing, like a tiny spark trying to get his attention."

    hide side dante neutral onlayer dante
    hide damon neutral
    with dissolve
    narrator "As the day went on, the feeling didn’t go away. Sometimes he would glance at a section of rock and just knew there was better spot a little to the left."

    narrator "Sometimes he would touch the wall and feel a strange warmth, like there was something alive moving underneath."

    narrator "By the end of their shift, Dante’s body was exhausted, but his mind was wide awake."

    scene barracks-night with fade
    narrator "When they finally returned to the barracks, everyone collapsed onto their beds, complaining about sore muscles and bruises. Dante laid on his back, staring at the ceiling."

    show rowan grin at nighttint with dissolve
    rowan "\"You survived your first day. Not bad.\""

    show rowan happy
    show side dante talk at left, nighttint onlayer dante with dissolve
    dante "\"Barely.\""

    show side dante neutral onlayer dante
    show rowan grin
    rowan "\"You’ll get used to it. We all did.\""
    show rowan happy

    hide rowan
    hide side dante neutral onlayer dante
    with dissolve
    narrator "Rowan turned over and was snoring a few minutes later."

    narrator "The lanterns dimmed one by one, leaving only a soft glow in the room."

    narrator "Dante brought his hand up and stared at his palm."

    dante "\"…What’s happening to me?\""

    narrator "He remembered the way the ore felt in his hand — how he knew its worth without checking."

    narrator "He remembered that faint line of light inside the stone."

    narrator "Somewhere deep down, a quiet thought stirred."

    narrator "This isn’t normal."

    narrator "He shut his eyes and tried to sleep, but the buzzing inside his chest lingered — pulling at his thoughts like a small, constant tug."

    narrator "Tonight, the dream that came to him was not of the warden shouting, but of distant light hidden under the earth, pulsing like a heartbeat."
    jump Chapter_2