label Chapter_2:
    stop music fadeout 5.0
    scene mine-entrance with longfade
    play music "<volume 0.7>audio/sad_full_gap.ogg" fadein 3.0
    narrator "As the months pass by, Dante can't ignore the fact that he had something inside that was allowing him to do these strange things. But what came with this gift also meant that he would be gone soon."
    
    narrator "Truth be told, he wasn't the only person in this mine that had this “gift”. There were a small number of people that could do things similar to him, but by the time their power was known, they disappeared."
    
    narrator "Whatever happened to them was unknown, but they probably vanished because of the narcissistic warden being envious of the slaves' powers. At least, that's what Dante theorised."
    
    narrator "Whatever the reason, he didn't want anything happening to him. He didn't want to leave his brother so suddenly just because he can see rocks differently. That would be cruel."

    narrator "But whatever happens, Dante would rather tell his brother about the situation and his supposed fate."

    narrator "Since it wasn't currently Dante’s shift, it gave him the perfect opportunity to speak with Damon. He goes to his brother, who was putting away heavy supplies by the supply area."

    show damon talk at nighttint with dissolve
    damon "\"Hey, you're here. I just finished up with this cargo here, so I'm finished with my tasks for the day. Since you're here, did you want to tell me something?\""

    menu:
        "\"I just wanted to be with my brother.\"":
            show damon neutral
            damon "..."
        "\"Is it a crime to be with my favourite person in the world?\"":
            show damon neutral
            damon "..."
        "\"Oh, nothing. I'm just bored...\"":
            show damon neutral
            damon "..."

    show damon talkneutral
    damon "\"There is definitely something you want to tell me, don't you?\""
    
    show damon happy
    show side dante sigh_alt2 at left, nighttint onlayer dante with dissolve
    dante "\"…Do you know anything about the others doing strange things?\""
    
    show damon talkneutral
    show side dante neutral at left onlayer dante
    damon "\"Strange things? You need to specify what you mean. Is there someone threatening you or something? Is that why you're asking?\""
    
    show damon neutral
    show side dante talk at left onlayer dante
    dante "\"No no, nothing like that. What I'm saying is…\""
    
    show side dante neutral at left onlayer dante
    narrator "Dante tries to explain in a way that he could understand. He fidgets fingers as he tries to get the words out, not making eye contact once with his brother."

    show side dante talk at left onlayer dante
    dante "\"...Remember that one girl? 1 year ago, around your age? I remembered that she was doing something with her water bottle differently than usual. And the next thing I knew, she was gone.\""
    
    show side dante neutral at left onlayer dante
    damon "..."
    
    show side dante talk at left onlayer dante
    dante "\"What about that one boy? I remember that he never carried a lantern around, cause he would produce light with his own hands. And later on, he was never seen again.\""
    
    show side dante neutral at left onlayer dante
    show damon talkneutral
    damon "\"What are you getting at?\""

    show side dante talk at left onlayer dante
    show damon neutral
    dante "\"I'm saying this because I have magic, for months now! I can see ore and minerals weirdly, and I feel the earth differently.\""
    
    show side dante neutral at left onlayer dante
    Ename "\"Sorry to interrupt your conversation, but I can't help but hear that you have magic?\""

    play sound "<volume 0.5>audio/mysterious.ogg"
    show damon lookside with moveinleft:
        xzoom -1
        xalign 0.1
    show elliot lookside at nighttint with dissolve:
        xalign 1.2
    show side dante question at left onlayer dante
    narrator "Dante was interrupted by an older gentleman. Judging on what he wore, he definitely was a rich man."
    
    narrator "He had the looks of a typical rich guy. A monocle on his left eye, a top hat, a dapper suit, a pocket watch chain hanging off his pocket, and a well groomed mustache."

    narrator "The brothers were startled with the sudden appearance of the older man. However, the two changed their demeanor to annoyance when the warden came by their direction."
    
    show side dante neutral at left onlayer dante
    show damon lookside:
        xzoom -1
        xalign 0.0
    show elliot lookside at nighttint:
        xalign 1.70
    with move
    show warden talkside at nighttint with dissolve:
        xalign 0.5

    warden "\"What are you two doing talking and loitering around here? You two better get back to work.\""

    show warden lookside at nighttint:
        xzoom -1
    show elliot talkside
    Ename "\"Oh, no need to fuss. This young man said that he had magic for months now.\""

    show warden talk 
    show elliot lookside
    warden "\"Oh does he now. And here I thought that you were nothing more than some useless pebble. Turns out you're a diamond in the rough. Lucky you.\""

    warden "\"Let’s not waste more time and discuss more of this in my office.\""

    show warden sneer
    show side dante scared onlayer dante at grab
    show elliot disappointed
    show damon scaredside:
        xalign -0.26
    narrator "The warden takes Dante's arm by force as he grits his teeth and starts trying to drag him to his office with the older gentleman standing by. But Dante thrashes and tries to pull himself in the other direction, actively resisting the warden."
    
    show damon scaredside
    damon "\"Sir, stop! What are you doing to him? You're hurting him!\""

    show warden talkside at nighttint:
        xzoom 1
    show damon scaredside
    warden "\"Stay out of this, slave. It's better for you to obey me. You’re lucky that I’m even letting you off the hook for doing nothing. Be grateful and stay in your place!\""

    show warden neutral
    narrator "The warden continues to try and drag the small boy, but even in his small size, he does all he can to get out of the warden’s grip."
    
    dante "\"No, let me go! I won’t let you take me like what you did to the others! I won’t leave with you, you jerk!\""
    
    show warden shout
    warden "\"Shut up, brat! It's bad enough that you weren't brought in sooner. So stop squirming like a rat and behave!\""

    show warden sweat at nighttint, bite
    narrator "Dante resorts to biting him on his arm, drawing blood in the process and causing the warden to let go of his arm. Dante runs and gets behind Damon, with blood staining his teeth."
    show warden shout
    warden "\"Dammit, you really are no different to dogs in the dirt! I will-\""

    show elliot shout at nighttint, bite
    show damon lookside:
        xalign 0.0
    show warden sweatside at nighttint:
        xzoom -1
    show side dante shocked at left onlayer dante
    Ename "\"That is enough!\""
    
    narrator "The older man shouted, stopping the warden in his tracks. Even in his arrogance, the warden wouldn't dare to defy his orders. The old man then came closer to the startled brothers."
    
    show elliot disappointed
    Ename "\"It has become clear to me that you lack the qualities that I expected of you as a warden. You will soon be evaluated and reprimanded.\""

    Ename "\"Not only do you abuse your position, but I have also heard that you have allegedly misused funds. Whether it's expenses for the operation itself, or for settling debts.\""

    Ename "\"Now leave to the infirmary for that bite. When you return to the office, wait outside until I am done discussing matters with this young man. And then I will decide what to do with you.\""
    
    show side dante neutral at left onlayer dante
    warden "\"...Understood...\""
    
    hide warden sweat with dissolve
    show damon lookside:
        xzoom -1
        xalign 0.1
    show elliot lookside at nighttint:
        xalign 1.2
    with move
    narrator "The warden went off with his head held low and a scowl on his face."

    show elliot talk
    Ename "\"Forgive me on his behalf for his lack of class and decency. I’ll evaluate and reprimand him as soon as possible.\""

    Ename "\"But I can assure you that I don't intend on disposing of anyone with magic.\""

    Ename "\"Will you at least let this old man explain more in my office? Your brother can accompany you as well if that is what you want.\""

    show damon neutral
    show elliot neutral
    show side dante happy onlayer dante
    narrator "With a forced smile, Dante reluctantly agreed."
    hide side dante neutral onlayer dante
    hide damon lookside
    hide elliot lookside
    with dissolve

    scene office with fade
    narrator "The brothers and the old man arrived in the office and sat down at opposite chairs facing each other. The coffee table had small treats on the plate, as well as prepared tea."
    
    narrator "The gentleman let the brothers take a bite from the treats and take a sip of tea. With no hesitation, the two ate the pastries — with each of them even gulping down their cups of tea. As they settled in, it was time for discussion."

    show damon lookside at nighttint:
        xzoom -1
        xalign 0.1
    show elliot talkside at nighttint:
        xalign 1.2
    show side dante neutral at left, nighttint onlayer dante
    with dissolve
    Ename "\"Let me properly introduce myself. I am Elliot Gunn, acting baron of house Gunn, and I personally oversee the mining factions around the mountain.\""

    Ename "\"May I have the pleasure of learning your names?\""

    show damon yessir
    show elliot lookside
    damon "\"I am Damon, and this young man is my brother, Dante.\""

    show damon happy
    show side dante determined onlayer dante
    narrator "He says as he ruffles Dante’s hair, despite his brother’s annoyance."
    
    show side dante neutral onlayer dante
    show damon lookside
    show elliot talk
    elliot "\"Now, I originally came here to inspect your warden and the barracks. But that all changed when I heard that you had magic.\""

    elliot "\"Before I start, did you have any questions in mind?\""

    show elliot neutral
    narrator "Dante jumps in, asking away."

    show side dante question at left onlayer dante
    show damon neutral
    dante "\"Yes, why do I have magic? Me and my brother weren't born to anyone with magic. What did you do to the other kids with magic? What do you want from me exactly?\""

    show side dante neutral onlayer dante
    show elliot talk
    show damon lookside
    elliot "\"No need to rush, all your questions will be answered.\""

    elliot "\"But I wish to ask of you...\""

    show elliot happy
    narrator "Elliot places his teacup on his saucer and puts it down on the old coffee table. He dabs his mouth with a napkin as he continues his discussion."

    show elliot talk
    elliot "\"I have a deal for you, dear boy.\""
    jump Chapter_3