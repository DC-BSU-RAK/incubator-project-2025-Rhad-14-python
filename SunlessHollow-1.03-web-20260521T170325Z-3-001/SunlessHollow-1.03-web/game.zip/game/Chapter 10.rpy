label Chapter_10_Protect:
    play music "audio/danger_full.ogg" fadein 2.0 volume 0.3
    narrator "Dante’s heart was pounding in his chest, but his body moved before he could think. Dante ran and put himself between the crystal and the warden."
    
    narrator "The warden clicks his tongue in annoyance at his stunt."

    show warden smug at leylinetint with dissolve
    warden "\"What? You want a bit of that glory? Well, make yourself useful and move aside. I want this finished as soon as possible.\""

    show side dante determinedtalk at left, leylinetint onlayer dante with dissolve
    dante "No!"
    
    show side dante determined onlayer dante
    show warden sneer
    warden "What did you just say to me?"

    show side dante determinedtalk onlayer dante
    dante "\"I said no! You are not uprooting the leyline! If you do, everything will get destroyed.\""

    show side dante determined onlayer dante
    narrator "The warden scoffed."
    
    warden "Does it look like I care? You led us here, so we finish the job. So move aside, if you don’t want to be blasted in the face."
    
    hide side dante onlayer dante with dissolve
    narrator "The warden turns to the mages."
    
    show warden talk
    warden "\"Don’t mind the kid, just do what I paid you to do.\""

    hide warden with dissolve
    narrator "One of the mages attacked first, forcing Dante to dodge back. The blast hit the crystal wall beside him and sent shards flying everywhere."

    narrator "Damon, still hurt, tried to pull himself up and blocked another miner from getting closer."
    
    show damon scream at leylinetint with dissolve
    damon "Stay away!"
    
    hide damon with dissolve
    narrator "The chamber filled with shouting and magic as the others pushed in. Dante looked back at the crystal, and the spark inside him suddenly reacted."
    
    narrator "The vein began pulsing brighter, almost like it was answering him."
    
    show leyline at caveshake
    init python :
        renpy.music.register_channel("rumblefx", mixer="sfx", loop=True)
    play rumblefx "audio/rumble.ogg" volume 0.5 fadein 0.3
    narrator "Then, the whole cave shook."
    
    narrator "A loud scream echoed from the tunnels, then another."
    
    show side dante question at left, leylinetint onlayer dante with dissolve
    dante "What just...?"
    
    hide side dante onlayer dante with dissolve
    narrator "Out of nowhere, crystal shards shot out from the ground, disorienting the other people around him."

    narrator "The ground cracked under their feet as the mages started backing up. Even the warden looked uneasy now, but he still ordered them to keep going."
    
    show warden shout at leylinetint with dissolve
    warden "\"Don’t stop!\""
    
    hide warden with dissolve
    narrator "Damon forced himself forward again, despite the pain."
    
    show damon scream at leylinetint with dissolve
    damon "\"If you keep messing with it, this whole place is gonna fall apart!\""
    
    hide damon with dissolve
    narrator "The crystal pulsed once more, brighter than before. The cave trembled hard, and the crystals continued to sprout out of the ground at fast rates, separating people from each other."
    
    narrator "Dante pressed his hands against the crystal, trying to hold his ground as the chamber started falling into chaos."
    
    jump Chapter_11_Protect

label Chapter_10_Step_aside:
    play music "audio/danger_full.ogg" fadein 2.0 volume 0.3
    narrator "Dante hesitated, then slowly stepped back."
    
    narrator "The warden smirked."
    
    show warden smug at leylinetint with dissolve
    warden "\"See, even your brother has common sense. I’ll consider mentioning your little contribution to my great find.\""
    
    hide warden with dissolve
    narrator "The mages moved in right away and started casting their magic to pull the crystal free. The leyline flickered once, then again, as if it didn’t like being touched."
    
    narrator "Damon looked at Dante in shock."
    
    show damon struggle at leylinetint with dissolve
    damon "\"Dante...?\""
    
    hide damon with dissolve
    narrator "But Dante stayed where he was, frozen."
    
    narrator "The extraction kept going, and the crystal’s glow started to dim in weird bursts. Dark shapes began appearing at the edges of the chamber, like shadows creeping in from the walls."
    
    narrator "Damon tried to stop the mages, stumbling forward despite his injured leg."
    
    show damon scream at leylinetint with dissolve
    damon "\"Stop! You don’t know what you’re doing!\""
    
    hide damon with dissolve
    narrator "One of the miners shoved him back hard, and Damon hit the ground again. He winced in pain, but still tried to get up."
    
    narrator "The warden ignored all of it and just kept ordering the mages to take the crystal faster."
    
    show warden talk at leylinetint with dissolve
    warden "\"Hurry up! I don't want anything going wrong.\""
    
    hide warden with dissolve
    narrator "But something went wrong."
    
    narrator "The air got colder. The hum from the vein sounded wrong now, shaky and distorted. The chamber started to feel heavy, like the whole mine was holding its breath."
    
    narrator "Then the dark shapes got clearer."
    
    narrator "Something was waking up."
    
    narrator "The mages worked fast. With Dante standing back, nothing stopped them from tearing into the leyline vein."
    jump Chapter_11_Step_aside
