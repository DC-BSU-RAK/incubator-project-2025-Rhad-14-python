label Chapter_6:
    narrator "Dante lost track of how long he had been walking. It felt like days. Down here, there was no sun, no bells, no warden yelling to mark the time."

    narrator "Just the steady pulse of the crystals, the glow of the fungi, and the constant tug of the pendant on his chest pulling him forward."
    
    narrator "He left signs whenever he could."

    narrator "Little stone arrows. Scratched symbols on flat walls. A strip of cloth tied around a root. Anything that would look out of place enough for Damon to recognize that Dante left these signs for him."
    
    show side dante talk at left, bluetint onlayer dante with dissolve
    dante "\"You better be following these, Damon.\""

    hide side dante onlayer dante with dissolve
    narrator "His legs were tired, but the air here felt... cleaner, somehow. The plants growing near the walls looked healthy. He passed tiny patches of flowers at one point, growing out of cracks in the stone like it was normal."
    
    narrator "Eventually, he entered an opening."

    narrator "Up ahead, between two thick roots and a curtain of hanging vines, he saw something that made him stop."
    
    scene tents with fade
    stop music fadeout 5.0
    narrator "Tents."

    play music "audio/phrase3.ogg" fadein 3.0 volume 0.85
    narrator "Not one or two, but a small cluster of tents arranged in a rough circle around an old campfire pit. The cave roof here opened up into a wide chamber, with crystals sprouting from the ceiling."

    dante "\"...A camp?\""

    narrator "He slowly stepped closer."

    narrator "It really did look like some kind of hidden camp, tucked away in this strange underground biome. "

    narrator "The tents were worn but still standing, their fabric stained and a little torn, but not completely ruined. Moss and cobwebs covered the sides of the tents."

    dante "\"So... someone has made it out this far before...\""

    narrator "He hadn't thought anyone else would have gotten this deep into the mine, especially not with how unstable everything was now."

    narrator "Maybe back then the tunnels were more solid. Maybe the beasts were calmer. Or maybe these people were just insane."

    narrator "Either way, they were long gone now."

    narrator "Dante stepped into the camp circle, glancing around."

    narrator "Some crates lay stacked neatly to one side. A couple of stools were toppled over, but the rest were lined up as if waiting for their owners to come back and sit."

    narrator "He moved towards the nearest tent and peeked inside."

    narrator "The blanket on the bed inside was still laid out. Not clean, but not torn apart either. On the small wooden crate acting as a bedside table, there were dried flower petals scattered in a small ring, like someone had placed a little bouquet there once."
    
    dante "\"This is... weirdly clean and neat...\""

    narrator "He checked the second tent. It was the same thing. A made bed, a few personal trinkets., and tools that hung carefully on nails hammered into a wooden post."
    
    narrator "The third tent, too. Organised. Quiet. Almost peaceful."
    
    narrator "All of the tents were organised and clean as well."

    narrator "It didn't match the idea of people running for their lives. It's like they were just living here peacefully."
    
    dante "\"So where did everyone go...?\""
    
    narrator "He kept searching until he reached the last tent, tucked slightly behind the others."

    narrator "This one looked different the second he saw it."
    
    scene insidetent with fade
    narrator "The fabric at the entrance was half tied, half hanging crooked. When Dante pushed it aside and stepped in, he realised why."
    
    narrator "It was a mess."
    
    narrator "The bedding was half off the mattress, as if someone had grabbed it in a hurry. The little table near the bed was covered in papers, some crumpled, some smeared." 
    
    narrator "Samples of rocks and crystals lay scattered on the floor. Tools were kicked into corners instead of hanging in their places."

    dante "\"...Someone had a rough time in here.\""

    narrator "He crouched down and picked up a sheet of paper from the floor. There were sketches of crystals on it, rough notes written in messy handwriting. Another page had a map with circles around certain spots."
    
    narrator "Dante put them back down carefully and scanned the table."

    narrator "Among all the clutter, one thing stood out."

    narrator "A journal."

    narrator "The cover was worn, the corners bent, but it was still in one piece. Dante picked it up and turned it over in his hands."

    dante "\"...This probably has their notes in it.\""

    menu:

        "\"Yeah... I should know what happened here.\"":
            jump read_journal
        "\"No. I don't wanna pry into their lives.\"":
            jump dont_read_journal    

    label read_journal:
        $ read_journal = True

        narrator "Dante let out a small sigh and opened the journal."

        narrator "The entries were short, only containing meaningless information of the writer and their team’s time in the cavern. Yet Dante couldn’t help but continue to read the little moments the ink captured years ago."

        narrator "The first pages were full of short entries, with at least three on each page."

        play sound "audio/page_turn2.ogg" volume 0.75
        show darkenscreen
        show day12 at top_middle
        with dissolve

        window hide
        pause
        dante "\"Arthur, Clover...\""

        narrator "He turned the page."

        play sound "audio/page_turn1.ogg" volume 0.65
        show day26 at top_middle
        window hide
        pause
        narrator "The handwriting was steady, a bit playful even."
        
        narrator "Each passage was wholesome, bringing a small smile on his face but it also brought an ache in his heart. He missed his brother and the team he came along with."

        narrator "As brief as their time was, he cherished the warmth and kindness they had. As for his brother, he was determined that he would find him, no matter what happened."

        narrator "And once he does, he’d finish this quest and get him, Damon, and the others out of this hellhole."

        narrator "He continued to turn the pages of the old journal."

        play sound "audio/page_turn2.ogg" volume 0.70
        show day30 at top_middle
        window hide
        pause
        narrator "Dante felt a small chill."

        narrator "{b}Leyline.{/b}"

        narrator "He flipped further ahead."
        
        play sound "audio/page_turn1.ogg" volume 0.75
        show day48 at top_middle
        window hide
        pause

        narrator "As he kept reading, the entries started changing."

        narrator "People's names came up less. Sentences got shorter... And the handwriting got a little shakier."

        narrator "The passages became more paranoid and fixated."

        play sound "audio/page_turn2.ogg" volume 0.67
        show day55 at top_middle
        window hide
        pause

        narrator "Dante swallowed and turned another page, finding the writing becoming more messy, with the words now coming in varying sizes as if it were written by a mad man."

        play sound "audio/page_turn1.ogg" volume 0.72
        show day60 at top_middle
        window hide
        pause

        narrator "Dante became horrified at the entry, and it only got worse from here."

        narrator "Their names were never mentioned again. With each passage, they became such intolerable people. The entries got longer and the handwriting was clearly more rushed."

        narrator "Dante's fingers tightened a little around the journal."

        narrator "He flipped further until he reached an entry that looked darker, ink pressed deeper into the page."

        play sound "audio/page_turn2.ogg" volume 0.70
        show unknown1 at top_middle
        window hide
        pause

        narrator "There were splotches of ink on the page, some being smudged by the writer. What was more interesting was the passage itself. Unlike the other passages, the author was giving a warning."

        narrator "Dante felt his chest tighten."

        narrator "He kept on reading."

        play sound "audio/page_turn1.ogg" volume 0.75
        show unknown2 at top_middle
        window hide
        pause

        narrator "The last line just ended there, fading off like the writer was interrupted."

        narrator "Dante stared at the page for a few seconds."

        play sound "audio/page_turn2.ogg" volume 0.75
        hide darkenscreen
        hide day12
        hide day26
        hide day30
        hide day48
        hide day55
        hide day60
        hide unknown1
        hide unknown2
        with dissolve

        dante "\"...So this person... Turned on their own team. Just to protect the vein.\""

        narrator "Dante placed down the journal back on the messy desk."

        jump after_journal
    
    label dont_read_journal:
        $ read_journal = False

        narrator "Dante stared at the journal for a moment, and then shut it after opening a single page."

        dante "\"...No. This was their story, not mine.\""

        narrator "He placed it back on the table where he found it, a bit more neatly."

        dante "\"All I need to know is that they didn't make it out. That's already enough.\""

        narrator "He glanced around the tent one more time — at the messy bed, the scattered tools, and the unfinished notes. Then he stepped back outside."

        narrator "Even without reading, the camp itself told him enough:"

        narrator "Someone had tried to go deeper."

        narrator "They'd been organised. Prepared."

        narrator "And still... they never came back."

        dante "\"If they knew it was dangerous enough to leave all this behind...\""

        narrator "Dante placed down the journal back on the messy desk."

        jump after_journal
    

    label after_journal:
        scene tents with fade
        narrator "Dante stepped out of the tent and stood still for a moment."

        narrator "This camp… these people… they were basically doing the same thing he and Damon were doing now. Chasing a leyline vein in the deep, dangerous parts of the mines."

        narrator "Except, these people were older. {w}Better equipped. {w}More prepared."

        narrator "And yet, they still ended up like this."

        dante "\"...You still failed, though.\""

        narrator "He didn't say it in a mocking way. It came out more tired than anything else."

        narrator "For a moment, he thought about turning back. The pendant at his chest gave off a small pulse, like it was waiting for him to decide."

        menu:

            "\"Turn back while I still can...\"":
                narrator "No matter what, one thing didn't change."

            "\"No. I need to find Damon.\"":
                narrator "No matter what, one thing didn't change."

            "\"Maybe I can do what they couldn't.\"":
                narrator "No matter what, one thing didn't change."

        narrator "Damon was still down here somewhere. {w}Alive, hopefully. {w}Hurt, probably. {w}And the pendant around his neck wasn't pulling him backwards."

        narrator "It was pulling him deeper."

        narrator "Dante stood up and looked around the camp one more time. There were more notes, more sketches, more bits of these strangers' lives left behind, but none of it changed what he had to do."
        
        scene tunnel-1 with fade
        narrator "He walked a slow circle around the area, checking the edges of the chamber. On one side, partly hidden behind a curtain of roots, he noticed a narrow tunnel entrance."

        narrator "It didn't look natural, the rock around it was cut more cleanly, like someone had dug it by hand."

        narrator "The pendant at his chest gave a small sharp pulse."

        dante "\"This must be the tunnel they mentioned...\""

        narrator "The journal writer had said it was a way back. An escape route."

        narrator "But the pendant didn't want him to go that way. Its pull was coming from a different direction, deeper into the unknown."

        narrator "He stood there for a moment between both paths."

        narrator "An old escape route carved by someone who clearly knew how dangerous the leyline was. Or the direction of the compass that might lead him to Damon... and the vein."

        narrator "Dante reached out and pressed his hand against the cave wall between the two paths."

        narrator "The stone was warm."

        dante "\"...Sorry, whoever you were.\""

        narrator "He turned away from the escape tunnel and chose the path the pendant was tugging him toward instead."

        scene tents with fade
        narrator "Before leaving the camp entirely, he stopped by one of the central crystal clusters and scratched his symbol — the circle with a line through it — onto the rock."
        
        dante "\"There. If Damon somehow finds this place too, he'll know I passed through.\""

        narrator "With one last look at the quiet, empty tents and the life that used to exist here, Dante tightened his grip on his pendant and walked onward, deeper into the mine."
        jump Chapter_7